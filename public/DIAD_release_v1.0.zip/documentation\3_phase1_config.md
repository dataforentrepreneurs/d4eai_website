# DIAD Phase 1 — Configuration & Bootstrap Script

This phase defines the configuration schema for each client and automates project bootstrapping using standard Python scripts.

---

## 1. Single Config Source of Truth

The entire DIAD pipeline is configured using a single JSON file: `config/client_rawdata.json`.
It controls:
- **Client Details**: Project ID, region, business name, and Netlify URL.
- **Source Paths**: Notion parent page IDs, Google Drive folders, and Confluence page ID.
- **Ingestion Mappings**: GA4 Property, Firestore collections, and export GCS buckets.
- **AI / LLM Settings**: Pinecone index properties (dimension, metric), embedding model, and primary/fallback LLM providers (e.g. OpenAI vs Gemini).

---

## 2. Bootstrapping Scripts

The bootstrap process is split into four idempotent Python scripts in the `scripts/` directory:

1. **Verify Authorization (`scripts/1_1_SA_GC_link.py`)**:
   - Assesses connectivity to GCP and ensures service account credentials are valid.
2. **Enable Required APIs (`scripts/1_2_enable_apis.py`)**:
   - Programmatically enables `bigquery`, `storage`, `run`, `secretmanager`, `cloudbuild`, and `artifactregistry` APIs.
3. **Assign IAM Roles (`scripts/1_3_assign_iam.py`)**:
   - Grants the standard roles (e.g., `bigquery.jobUser`, `secretmanager.secretAccessor`) to the Runtime SA.
4. **Create Resources (`scripts/1_4_bootstrap_resources.py`)**:
   - Creates the BigQuery datasets and prepares the GCS bucket folder prefixes.

---

## 3. How to Run Bootstrap (Local)

Run the scripts in order using the project's virtual environment:
```powershell
# Load environment variables
. .\env.ps1

# Run bootstrap scripts
python scripts/1_1_SA_GC_link.py --config config/client_rawdata.json
python scripts/1_2_enable_apis.py --config config/client_rawdata.json
python scripts/1_3_assign_iam.py --config config/client_rawdata.json
python scripts/1_4_bootstrap_resources.py --config config/client_rawdata.json
```
Verify that all datasets are successfully provisioned in the BigQuery console.
