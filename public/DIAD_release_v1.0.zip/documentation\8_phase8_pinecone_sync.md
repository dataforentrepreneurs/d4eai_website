# DIAD Phase 8 — Document Intelligence (Pinecone Ingestion)

This phase implements the unstructured document crawlers for Notion, Google Drive, and Confluence, generates text chunk embeddings, and synchronizes them to Pinecone with visibility access controls.

---

## 1. Vector Database Standards

To allow fast and cheap local embedding processing, we use:
- **Vector Database**: Pinecone
- **Index Name**: `diad-docs-hf`
- **Embedding Model**: HuggingFace `sentence-transformers/all-MiniLM-L6-v2` (runs locally, O(0) API cost)
- **Dimension**: 384
- **Distance Metric**: Cosine

---

## 2. Ingestion Access Controls (Visibility Model)

To guarantee that internal document information (e.g. employee roadmaps, internal policies) is never shown to external store customers:
- Each text chunk is tagged with a `visibility` metadata field (`internal` or `external`).
- **Google Drive**: Folders listed in `document_visibility.drive.external_folder_ids` are tagged `external`. All others are `internal`.
- **Notion**: Page IDs listed in `document_visibility.notion.external_page_ids` are tagged `external`. All others are `internal`.
- **Confluence**: Pages matching spaces in `document_visibility.confluence.external_space_keys` are tagged `external`. All others are `internal`.

The external chatbot API query restricts retrievals using Pinecone's filter expression: `{"visibility": "external"}`.

---

## 3. Scripts

The crawling and indexing operations are managed under `scripts/phase8/`:

1. **`8_1_create_pinecone_index.py`**:
   - Assesses Pinecone access and creates the index with dimension 384 if it does not exist.
2. **`8_2_sync_docs_to_pinecone.py`**:
   - Crawls Google Drive folder, Notion pages, and Confluence wiki spaces.
   - Cleans and chunks the documents, extracts metadata (author, visibility, namespace), generates embeddings, and upserts them to Pinecone.
3. **`8_3_query_docs.py`**:
   - Runs validation query requests (with visibility filtering) to check database returns.
4. **`8_4_pinecone_status_check.py`**:
   - Prints the current index status, namespace counts, and fullness metrics.

---

## 4. Run Commands

To trigger Phase 8 document synchronization manually:
```powershell
# Load variables & active credentials
. .\env.ps1

# Run index setup and crawling sync
python -X utf8 scripts/phase8/8_1_create_pinecone_index.py
python -X utf8 scripts/phase8/8_2_sync_docs_to_pinecone.py

# Verify synchronization
python -X utf8 scripts/phase8/8_4_pinecone_status_check.py
python -X utf8 scripts/phase8/8_3_query_docs.py
```
Check that the vector counts are updated.
