# client_jobs/env.ps1
# Only file to edit (per client folder / repo).

# Path to DIAD config
$CONFIG_PATH = "config/client_rawdata.json"

# Cloud Run Job settings
$JOB_NAME = "diad-phase8-sync-docs"

# Cloud Scheduler settings (Asia/Singapore - Quarterly on the 1st at 02:00 AM)
$SCHEDULER_NAME = "diad-phase8-sync-quarterly"
$CRON = "0 2 1 */3 *"
$TIME_ZONE = "Asia/Singapore"


# Artifact Registry (Jobs image)
$AR_REPO = "diad-jobs"
$IMAGE_NAME = "diad-phase-jobs"
$IMAGE_TAG = "v1"

# Build context (repo root)
$SOURCE_DIR = "."

# Secrets you want to store (names). Values are prompted in 2_upsert_secrets.ps1
# Add/remove as needed.
$SECRETS = @(
  "PINECONE_API_KEY",
  "NOTION_TOKEN",
  "CONFLUENCE_TOKEN",
  "OPENAI_API_KEY"
)
