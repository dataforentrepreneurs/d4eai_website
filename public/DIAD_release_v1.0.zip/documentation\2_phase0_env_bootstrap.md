# DIAD Phase 0 — Environment Bootstrap

This phase establishes the foundational GCP environment, provisioning the necessary service accounts, IAM roles, GCS buckets, and BigQuery datasets.

---

## 1. Required GCP Service Accounts

We recommend using two distinct service accounts to follow the principle of least privilege:

1. **Deployer SA** (`chatbot-deploy-clientside@<PROJECT_ID>.iam.gserviceaccount.com`):
   - **Purpose**: Used by the deployment script to build images (Cloud Build) and deploy Cloud Run revisions.
2. **Runtime SA** (`chatbot-access-sources-clients@<PROJECT_ID>.iam.gserviceaccount.com`):
   - **Purpose**: Assigned to the running Cloud Run containers. Used to run BigQuery queries, read secrets from Secret Manager, and write system logs.

---

## 2. Minimal Required IAM Roles

### 2.1 Deployer SA Roles:
- `roles/run.admin` (Manage Cloud Run services)
- `roles/cloudbuild.builds.editor` (Submit and monitor Cloud Builds)
- `roles/storage.admin` (Manage files in deployment buckets)
- `roles/serviceusage.serviceUsageConsumer` (Consume API quotas)
- `roles/iam.serviceAccountUser` (Attach the Runtime SA to Cloud Run services)

### 2.2 Runtime SA Roles:
- `roles/bigquery.jobUser` (Run SQL query jobs)
- `roles/bigquery.dataViewer` (Read data from BigQuery datasets)
- `roles/secretmanager.secretAccessor` (Retrieve OpenAI, Gemini, and Pinecone API keys at runtime)
- `roles/logging.logWriter` (Write standard logs)

---

## 3. GCS Bucket Layout

A single unified bucket (`gs://<client-project-id>/` or `gs://diamante-diad3/`) is created with the following directory structures:
- `landing/phase3/` (Landing area for incoming e-commerce data seeds)
- `raw/firestore/` (Firestore database dumps)
- `raw/firebase_auth_users/` (Firebase auth database dumps)
- `raw/google_analytics/` (GA4 event exports)

---

## 4. BigQuery Datasets

The initial environment requires the following datasets:
- `firestore_export` (Firestore collection tables)
- `firebase_auth_export` (Firebase Auth tables)
- `ecommerce_raw` (Raw CSV / data seeds ingestion)
- `ecommerce_canonical` (Staging/canonical modeled views)
- `ecommerce_mart` (Business-ready order dossiers and customer 360 tables)
