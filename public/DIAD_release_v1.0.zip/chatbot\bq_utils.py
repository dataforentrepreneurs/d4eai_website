# chatbot/bq_utils.py
"""
Shared BigQuery + config helpers for DIAD chatbots.

- Reads config/client_rawdata.json
- Supports raw styles:
  A) {"client": {...}}
  B) {"clients": {"diamante": {...}}} + CLIENT_ID env var
- build_bq_client() uses:
  - service account json file if configured (local)
  - ADC if not (Cloud Run)
"""

import json
import logging
from pathlib import Path
from typing import Optional
import os

from google.cloud import bigquery
from google.oauth2 import service_account

ROOT_DIR = Path(__file__).resolve().parents[1]  # diad/
DEFAULT_CONFIG_PATH = ROOT_DIR / "config" / "client_rawdata.json"

logger = logging.getLogger(__name__)


def load_raw_config(path: Optional[Path] = None) -> dict:
    if path is None:
        path = DEFAULT_CONFIG_PATH
    path = path.resolve()

    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _resolve_candidate_path(value: str) -> Optional[Path]:
    p = Path(value)
    candidates = []
    if p.is_absolute():
        candidates.append(p)
    else:
        candidates.append(ROOT_DIR / p)
        candidates.append(ROOT_DIR / "config" / p)

    for cand in candidates:
        if cand.exists():
            return cand
    return None


def get_client_cfg(raw: dict) -> dict:
    """
    Supports BOTH config styles:
      A) {"client": {...}}
      B) {"clients": {"diamante": {...}, "foo": {...}}} + CLIENT_ID env var
    """
    if "client" in raw and isinstance(raw["client"], dict):
        return raw["client"]

    clients = raw.get("clients") or {}
    client_id = os.getenv("CLIENT_ID", "default")
    cfg = clients.get(client_id)

    if not isinstance(cfg, dict):
        raise RuntimeError(
            f"Client config not found. Expected raw.client OR raw.clients['{client_id}']"
        )
    return cfg


def build_bq_client(raw_cfg: Optional[dict] = None) -> bigquery.Client:
    """
    Cloud Run: use Application Default Credentials (attached service account).
    Local: optionally use service account json file if provided in config.gcp.

    Also tolerates being passed client_cfg by mistake.
    """
    if raw_cfg is None:
        raw_cfg = load_raw_config()

    # If someone passes client_cfg directly, wrap it so get_client_cfg works.
    if "project_id" in raw_cfg and "client" not in raw_cfg and "clients" not in raw_cfg:
        raw_cfg = {"client": raw_cfg}

    client_cfg = get_client_cfg(raw_cfg)

    project_id = client_cfg.get("project_id")
    location = client_cfg.get("bq_location", "asia-southeast1")
    if not project_id:
        raise RuntimeError("client.project_id missing in client_rawdata.json")

    gcp_cfg = raw_cfg.get("gcp") or {}
    sa_path_val = (
        gcp_cfg.get("service_account_key_path")
        or gcp_cfg.get("service_account_file")
        or gcp_cfg.get("service_account_path")
    )

    # ✅ Cloud Run: always use ADC, never local key files
    # Cloud Run sets K_SERVICE automatically.
    if os.getenv("K_SERVICE"):
        if sa_path_val:
            logger.info("Cloud Run detected (K_SERVICE set). Ignoring service_account_path and using ADC.")
        sa_path_val = None

    if sa_path_val:
        sa_path = _resolve_candidate_path(sa_path_val)
        if not sa_path:
            raise RuntimeError(f"Service account path set but not found: {sa_path_val}")
        creds = service_account.Credentials.from_service_account_file(str(sa_path))
        return bigquery.Client(project=project_id, credentials=creds, location=location)

    # ✅ Default path (ADC)
    return bigquery.Client(project=project_id, location=location)
