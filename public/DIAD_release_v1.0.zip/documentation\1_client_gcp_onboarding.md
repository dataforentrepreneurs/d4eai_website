# DIAD Onboarding & Client GCP Setup Guide

This guide explains how to set up the client GCP project, link billing, configure Google Analytics (GA4) and Firebase exports, and secure the internal chatbot UI using Identity-Aware Proxy (IAP).

---

## 1. GCP Project & Billing Setup

### 1.1 Project Creation
Each client requires a dedicated GCP Project (e.g., `diamante-diad3`).
- Create the project in the [GCP Console](https://console.cloud.google.com/).
- Note the **Project ID** and **Project Number**.

### 1.2 Enable Billing (Critical Step)
- Link the project to an active billing account by visiting [GCP Billing Setup](https://console.developers.google.com/billing/enable?project=diamante-diad3).
- **Note**: Cloud Run deployments, Secret Manager, Cloud Build, and Cloud Scheduler will fail or return `503 Server Error` if billing is disabled.

---

## 2. GA4 Property & Web Ingestion

To capture customer behavior telemetry:
1. Create a GA4 property for the client website (e.g., *The Diamante Collections*).
2. Create a **Web Data Stream** inside GA4 Admin.
3. Fetch the **Measurement ID** (e.g., `G-5Q1ZF0LE33`) and **Property ID** (e.g., `502750679`).
4. Update these values in the `sources.google_analytics` section of `config/client_rawdata.json`.
5. Install the Global Site Tag (`gtag.js`) into the `<head>` of all client web pages (deployed automatically via Netlify or Firebase hosting).

---

## 3. Firebase Data Export

To flow operational telemetry (auth users, firestore collections) to BigQuery:
1. In the Firebase Console, go to **Project Settings → Integrations**.
2. Link **Google Analytics** and **BigQuery**.
3. Enable **Firestore** and **Google Analytics** exports to BigQuery.
4. Verify that raw export datasets land in BigQuery under the names:
   - `firestore_export` (for collection dumps)
   - `firebase_auth_export` (for users lists)

---

## 4. Securing the Internal Chatbot UI (IAP Setup)

The internal dashboard is private and must only be accessed by authorized employees. We protect the UI service (`diad-internal-ui`) using Identity-Aware Proxy (IAP).

### 4.1 Create OAuth Credentials
1. Go to **APIs & Services → Credentials** in the GCP Console.
2. Create an **OAuth Client ID** of type **Web Application**.
3. Note the Credentials:
   - **Client ID**: `<YOUR_OAUTH_CLIENT_ID>`
   - **Client Secret**: `<YOUR_OAUTH_CLIENT_SECRET>`
4. Add the redirect URI (e.g., the Cloud Run UI URL followed by `/oauth2callback`).

### 4.2 Enable IAP on Cloud Run
Enable IAP on the internal service using the helper script:
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\iap\4_iap_enable.ps1 `
  -OAuthClientId "<YOUR_OAUTH_CLIENT_ID>" `
  -OAuthClientSecret "<YOUR_OAUTH_CLIENT_SECRET>"
```
Once enabled, only users granted the `IAP-secured Web App User` role will be allowed to load the UI.
