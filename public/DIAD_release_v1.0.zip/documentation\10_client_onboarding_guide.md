# Client Onboarding Checklist (Non-Technical)

Welcome to the **Data in a Day (DIAD)** platform! This simple checklist guides you through connecting your website, transactional data, and document sources (Notion, Drive, Confluence) to your new AI chatbot.

---

## Step 1: Provide Website & Project Details
Provide the following details to your DIAD Integration Admin:
- **Your website URL** (e.g., `https://yourstore.com`)
- **Your business name** (e.g., *The Diamante Collections*)

---

## Step 2: Connect Your Document Sources (For Chatbot FAQ & Help Center)

You can share data from one or all of the following platforms. Your AI chatbot will read this documentation to answer questions.

### 📁 Option A: Google Drive
1. Create a dedicated folder in Google Drive (e.g., "DIAD Public Help Center Docs").
2. Put any public FAQ files, return policies, or guides (Google Docs or PDFs) in this folder.
3. **Share the Folder**: Share it with our DIAD Admin service account (or list the **Folder ID** from the browser URL bar and send it to us).

### 📓 Option B: Notion Pages
1. Go to **Notion → Settings & Members → Connections → Develop or Manage Integrations**.
2. Click **New Integration**, name it "DIAD Integration", and click **Submit** to copy the **Internal Integration Token**.
3. Go to the parent workspace page you want your chatbot to access (e.g., "Public Help Center").
4. Click the three dots `...` in the top right, select **Add Connections**, and search/select **DIAD Integration**.
5. Copy the **Token** and the **Page ID** (from the URL string), and send them to the DIAD Admin.

### 🏢 Option C: Confluence Space
1. Create a public help space or article list in Confluence.
2. Generate an Atlassian API Token from your [Atlassian Account Profile page](https://id.atlassian.com/manage-profile/security/api-tokens).
3. Send the **Base URL** (e.g., `https://yourbusiness.atlassian.net/wiki`), **Space Key** (e.g., `HELP`), and **API Token** to the DIAD Admin.

---

## Step 3: Link Your Telemetry & Sales Streams (For Chatbot Order Lookups)

### 📈 1. Google Analytics (GA4) Linking
To let the pipeline read customer website visits:
1. In the Google Analytics interface, go to **Admin (gear icon) → Product Links → BigQuery Links**.
2. Click **Link**, select your client GCP project ID, configure Daily exports, and click **Submit**.

### 📱 2. Firebase Database Linking (If using Firebase/Firestore)
To flow user sign-ups and order statuses:
1. Open the Firebase Console.
2. Go to **Project Settings (gear icon) → Integrations**.
3. Under the **BigQuery** card, click **Link** (or **Manage**), and ensure **Firestore** and **Google Analytics** integrations are turned ON.
