# DIAD Phase 2 — Data Import Engine (Firestore & Firebase Auth)

This phase implements the ingestion of raw Firestore database tables and Firebase Auth lists into BigQuery, creating the raw telemetry foundation of the data warehouse.

---

## 1. Firestore Export to BigQuery

Operational tables (like `orders` collection) are periodically dumped to GCS and loaded into BigQuery.

### 1.1 Script: `scripts/2_1_firestore_to_bq.py`
- Reads target collections from `client_rawdata.json` (`sources.firestore.collections`).
- Performs Firestore exports to `gs://<client-bucket>/raw/firestore/`.
- Loads the exports from GCS into BigQuery `firestore_export.<collection>` tables using a `WRITE_TRUNCATE` write disposition.

---

## 2. Firebase Auth Export to BigQuery

To resolve customer identifiers and match emails to order histories:

### 2.1 Script: `scripts/2_2_firebase_auth_users_to_bq.py`
- Connects to Firebase Auth.
- Dumps the list of all registered auth users into `gs://<client-bucket>/raw/firebase_auth_users/`.
- Loads this user database into `firebase_auth_export.firebase_auth_users` table in BigQuery.

---

## 3. Consolidation Layer

Once firestore and auth tables land in BigQuery, they are consolidated to build historical partitioned tables.

### 3.1 Script: `scripts/2_3_build_consolidated.py`
- Reads from raw schemas.
- Consolidates and structures JSON payloads.
- Generates clean historical tables under the `firebase_consolidated` dataset.

---

## 4. Run Commands

To trigger Phase 2 ingestion manually:
```powershell
python scripts/2_1_firestore_to_bq.py --config config/client_rawdata.json
python scripts/2_2_firebase_auth_users_to_bq.py --config config/client_rawdata.json
python scripts/2_3_build_consolidated.py --config config/client_rawdata.json --all-history
```
Verify that BQ tables are populated with correct customer record schemas.
