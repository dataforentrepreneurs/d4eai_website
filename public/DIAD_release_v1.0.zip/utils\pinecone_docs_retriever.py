"""
Docstring for utils.pinecone_docs_retriever
Purpose:
stored docs in 3 namespaces (gdrive/notion/confluence)
Pinecone can only query one namespace at a time
So we query all three, then merge by score.

"""
from __future__ import annotations

import os
from typing import Dict, List, Optional, Tuple

from pinecone import Pinecone


# Namespaces you used during upsert in Phase 8
DOC_NAMESPACES = ["gdrive", "notion", "confluence"]


def _get_pinecone_index(index_name: str):
    api_key = os.getenv("PINECONE_API_KEY")
    if not api_key:
        raise RuntimeError("PINECONE_API_KEY is missing in environment variables.")

    pc = Pinecone(api_key=api_key)
    return pc.Index(index_name)


def _describe_dim(index_name: str) -> Optional[int]:
    api_key = os.getenv("PINECONE_API_KEY")
    if not api_key:
        return None
    try:
        pc = Pinecone(api_key=api_key)
        desc = pc.describe_index(index_name)
        return desc.dimension
    except Exception:
        return None


def query_docs_pinecone(
    *,
    index_name: str,
    query_vector: List[float],
    top_k: int,
    visibility_allow: List[str],
    namespaces: Optional[List[str]] = None,
) -> List[Dict]:
    """
    Query Pinecone docs across multiple namespaces and return merged top results.
    We filter on metadata.visibility (internal/external).
    """
    index = _get_pinecone_index(index_name)
    namespaces = namespaces or DOC_NAMESPACES

    # Pinecone metadata filter
    meta_filter = {"visibility": {"$in": visibility_allow}}

    all_matches: List[Dict] = []

    for ns in namespaces:
        try:
            res = index.query(
                namespace=ns,
                vector=query_vector,
                top_k=top_k,
                include_metadata=True,
                filter=meta_filter,
            )
            matches = res.get("matches", []) or []
            all_matches.extend(matches)
        except Exception:
            # If a namespace doesn't exist yet or errors, just skip it
            continue

    # Sort merged results by score (descending) and keep global top_k
    all_matches.sort(key=lambda m: m.get("score", 0.0), reverse=True)
    return all_matches[:top_k]


def matches_to_context(matches: List[Dict]) -> Tuple[str, List[Dict]]:
    """
    Converts Pinecone matches into a context string + a lightweight citations list.
    """
    chunks = []
    citations = []

    for m in matches:
        md = m.get("metadata", {}) or {}
        src = md.get("source", "unknown")
        name = md.get("doc_name", md.get("doc_id", "unknown"))
        text = (md.get("text") or "").strip()
        score = m.get("score", 0.0)

        if not text:
            continue

        chunks.append(f"[{src}] {name}\n{text}")
        citations.append(
            {
                "source": src,
                "doc_name": name,
                "doc_id": md.get("doc_id"),
                "score": score,
                "visibility": md.get("visibility"),
            }
        )

    context = "\n\n---\n\n".join(chunks)
    return context, citations


def get_index_dimension(index_name: str) -> Optional[int]:
    return _describe_dim(index_name)
