# Admin Client Onboarding Manual (Developer-Led)

This guide details the exact steps you (the DIAD Admin) must take to onboard a new client onto the DIAD platform this month.

---

## Part 1: Information Gathering (From Client)

Send the **[Client Onboarding Checklist](file:///d:/DataForEntrepreneurs/diad/documentation/10_client_onboarding_guide.md)** to the client. Collect the following details:
1. **Google Drive Folder ID** (containing FAQ files/policies).
2. **Notion Integration Token & Page ID** (or Confluence Space URL + API token).
3. **Google Analytics (GA4) Property ID & Measurement ID**.
4. Confirmation that they linked GA4/Firebase to BigQuery.

---

## Part 2: GCP Project & Authentication Setup

1. **Create GCP Project**: Create a new GCP project for the client in the Google Cloud Console (e.g. `clientname-diad`).
2. **Link Billing**: Ensure a billing account is linked to the project.
3. **Generate Service Account Key**:
   - Select the default compute service account (or create a new SA named `diad-deployer-sa`).
   - Go to **Keys → Add Key → Create New Key → JSON**.
   - Download the JSON file and save it inside the project's `keys/` directory (e.g., `keys/clientname-diad-key.json`).

---

## Part 3: Configure the Client Config File

Create a configuration file for the client (e.g. `config/clientname_rawdata.json`). Fill in:
- `client.project_id`: The client's GCP Project ID.
- `client.export.bucket` & `ingest.bucket`: Set a unique bucket name (e.g., `clientname-diad-storage`).
- `client.doc_sources`: Input their Drive folder IDs and Notion page IDs.
- `gcp`: Set the key paths pointing to the JSON file you downloaded in Part 2.

---

## Part 4: Run the Bootstrap & Ingestion Pipeline

Open Windows PowerShell, activate your virtual environment, and run the pipeline scripts in order:

```powershell
# 1. Load active project environment variables
$env:GOOGLE_CLOUD_PROJECT = "clientname-diad"
$env:GOOGLE_APPLICATION_CREDENTIALS = "D:\DataForEntrepreneurs\diad\keys\clientname-diad-key.json"

# 2. Bootstrap resources (APIs, Buckets, and BQ Datasets)
python scripts/1_1_SA_GC_link.py --config config/clientname_rawdata.json
python scripts/1_2_enable_apis.py --config config/clientname_rawdata.json
python scripts/1_4_bootstrap_resources.py --config config/clientname_rawdata.json

# 3. Load transactional CSV data
python scripts/phase3/run_all.py --config config/clientname_rawdata.json

# 4. Build the dbt modeled warehouse
python scripts/6_1_run_dbt.py --mode full

# 5. Build chatbot aggregate tables
python scripts/7_run_all.py
```

---

## Part 5: Secrets Manager Setup

Upload the client's API credentials (Notion, Confluence, Pinecone, and OpenAI keys) to GCP Secret Manager so they can be read securely by the running chatbot container:

```powershell
# 1. Create secrets inside client project
for S in OPENAI_API_KEY PINECONE_API_KEY NOTION_API_KEY CONFLUENCE_API_TOKEN; do
  gcloud secrets create "$S" --replication-policy="automatic" --project "clientname-diad"
done

# 2. Add client's private tokens as versions (replace token strings below)
printf "%s" "CLIENT_OPENAI_KEY"   | gcloud secrets versions add OPENAI_API_KEY       --data-file=- --project "clientname-diad"
printf "%s" "CLIENT_PINECONE_KEY" | gcloud secrets versions add PINECONE_API_KEY     --data-file=- --project "clientname-diad"
printf "%s" "CLIENT_NOTION_TOKEN" | gcloud secrets versions add NOTION_API_KEY       --data-file=- --project "clientname-diad"
printf "%s" "CLIENT_CONFL_TOKEN"  | gcloud secrets versions add CONFLUENCE_API_TOKEN --data-file=- --project "clientname-diad"
```

---

## Part 6: Index Documents to Pinecone

Once the secrets are set, run the vector indexing script to sync all Drive/Notion pages into Pinecone:

```powershell
# Create Pinecone index
python -X utf8 scripts/phase8/8_1_create_pinecone_index.py

# Sync docs
python -X utf8 scripts/phase8/8_2_sync_docs_to_pinecone.py
```

---

## Part 7: Deploy Chatbots & Daily Scheduler

1. **Deploy to Cloud Run**: Build the container and deploy the APIs:
   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts/phase9/9_2_deploy_cloud_run.ps1 -ConfigPath config/clientname_rawdata.json
   ```
2. **Deploy Daily Scheduler Sync Job**: Deploy the automatic sync job:
   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts/phase9/client_jobs/9_run_all.ps1
   ```
3. **Test chatbot endpoints**: Run smoke tests to verify the deployment is healthy:
   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts/phase9/9_3_smoke_test.ps1
   ```
