# DIAD Platform Documentation (Phases 0–9 Master Guides)

Welcome to the **Data in a Day (DIAD) Platform v2 Documentation**. This folder contains the complete, production-grade technical guides for bootstrapping, running, and deploying the DIAD pipeline for *The Diamante Collections* client project.

---

## Guide Index

Click on the guides below to navigate:

1. **[System Architecture Guide](file:///d:/DataForEntrepreneurs/diad/documentation/0_diad_architecture.md)**: Explains the directory folder structure, technical design decisions, and database schemas.
2. **[Client GCP Onboarding & Security](file:///d:/DataForEntrepreneurs/diad/documentation/1_client_gcp_onboarding.md)**: GCP admin setup for billing, GA4 streams, OAuth client IDs, and securing the internal UI using IAP.
3. **[Phase 0 — Environment Bootstrap](file:///d:/DataForEntrepreneurs/diad/documentation/2_phase0_env_bootstrap.md)**: Cloud service account creation, IAM role assignments, GCS bucket layouts, and BigQuery raw dataset structures.
4. **[Phase 1 — Configuration Schema](file:///d:/DataForEntrepreneurs/diad/documentation/3_phase1_config.md)**: Schema guides for `config/client_rawdata.json` and bootstrap commands.
5. **[Phase 2 — Data Import Ingestion](file:///d:/DataForEntrepreneurs/diad/documentation/4_phase2_firestore_ingestion.md)**: Landing Firebase Auth user lists and Firestore collections.
6. **[Phase 3 — CSV Seed Ingestion](file:///d:/DataForEntrepreneurs/diad/documentation/5_phase3_csv_ingestion.md)**: Ingesting database seeds into schema-aligned raw BigQuery tables.
7. **[Phase 6A — dbt modeled Warehouse](file:///d:/DataForEntrepreneurs/diad/documentation/6_phase6_dbt_modeling.md)**: Transforming staging datasets to marts using dbt build commands.
8. **[Phase 7 — Chatbot Prep Marts](file:///d:/DataForEntrepreneurs/diad/documentation/7_phase7_chatbot_prep.md)**: Materializing order dossiers and Customer 360 tables.
9. **[Phase 8 — Document sync Ingestion](file:///d:/DataForEntrepreneurs/diad/documentation/8_phase8_pinecone_sync.md)**: Crawling Notion, Confluence, and Drive, generating MiniLM embeddings, and syncing to Pinecone.
10. **[Phase 9 — Deployment & Cloud Run Jobs](file:///d:/DataForEntrepreneurs/diad/documentation/9_phase9_chatbot_deployment.md)**: Deploying the chatbot APIs to Cloud Run, scheduling daily sync jobs, and running test validations.
11. **[Client Onboarding Checklist (Non-Technical)](file:///d:/DataForEntrepreneurs/diad/documentation/10_client_onboarding_guide.md)**: A simple step-by-step connection checklist for Google Drive, Notion, Confluence, GA4, and Firebase specifically written for your non-technical clients.
12. **[Admin Client Onboarding Manual (Developer-Led)](file:///d:/DataForEntrepreneurs/diad/documentation/11_admin_client_onboarding.md)**: A step-by-step pipeline manual detailing the setup scripts, JSON configs, Secret Manager inputs, and Cloud Run deployments for the DIAD Administrator.
13. **[Self-Serve Client Onboarding Blueprint](file:///d:/DataForEntrepreneurs/diad/documentation/12_self_serve_architecture.md)**: Technical blueprint detailing the Next.js frontend, OAuth integrations, and Analytics Admin API automation required for 100% self-serve onboarding.

