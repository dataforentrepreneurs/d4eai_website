from ast import Call
import logging
import os
from pyexpat.errors import messages
from typing import List, Dict, Optional

from openai import OpenAI
import requests

log = logging.getLogger(__name__)


class LLMClient:
    """
    Primary + fallback LLM wrapper for DIAD chatbots.

    ✅ Primary: OpenAI (chat.completions)
    ✅ Fallback: Gemini (REST API) – optional

    -----------------------------
    Config shape (client_rawdata.json)
    -----------------------------

    Preferred (explicit primary/fallback):

    "llm": {
      "primary": {
        "provider": "openai",
        "model": "gpt-4.1-mini",
        "api_key": "sk-OPENAI-KEY-HERE"
      },
      "fallback": {
        "provider": "google",
        "model": "gemini-1.5-flash",
        "api_key": "AIza-GEMINI-KEY-HERE"
      }
    }

    Legacy support (still works):

    "llm": {
      "provider": "openai",
      "chat_model": "gpt-4.1-mini",
      "fallback_model": "gpt-4o-mini",
      "openai_api_key": "sk-OPENAI-KEY-HERE",
      "gemini_api_key": "AIza-GEMINI-KEY-HERE"
    }

    Also supported (as last-resort):

    "secrets": {
      "openai_api_key": "...",
      "gemini_api_key": "..."
    }

    Environment variables (final fallback):

      OPENAI_API_KEY, GEMINI_API_KEY
    """

    def __init__(self, raw_cfg: dict):
        self.raw_cfg = raw_cfg
        self.llm_cfg = raw_cfg.get("llm", {}) or {}
        self.secrets_cfg = raw_cfg.get("secrets", {}) or {}

        # -------------------------
        # Resolve primary config
        # -------------------------
        primary_cfg = self.llm_cfg.get("primary") or {}

        # Provider: prefer llm.primary.provider, else legacy llm.provider
        self.primary_provider: str = (
            primary_cfg.get("provider")
            or self.llm_cfg.get("provider")
            or "openai"
        ).lower()

        # Model: prefer llm.primary.model, else legacy llm.chat_model
        self.primary_model: str = (
            primary_cfg.get("model")
            or self.llm_cfg.get("chat_model")
            or "gpt-4o-mini"
        )

        # OpenAI API key – multiple locations supported
        self.openai_api_key: Optional[str] = (
            primary_cfg.get("api_key")
            or self.llm_cfg.get("openai_api_key")
            or self.secrets_cfg.get("openai_api_key")
            or os.environ.get("OPENAI_API_KEY")
        )

        if self.primary_provider == "openai":
            if not self.openai_api_key:
                raise ValueError(
                    "OpenAI API key missing. Please set one of:\n"
                    " - llm.primary.api_key\n"
                    " - llm.openai_api_key\n"
                    " - secrets.openai_api_key\n"
                    " - OPENAI_API_KEY environment variable"
                )
            self.openai_client = OpenAI(api_key=self.openai_api_key)
            log.info("LLMClient: OpenAI primary configured with model '%s'.", self.primary_model)
        else:
            raise ValueError(
                f"LLMClient currently supports only primary.provider='openai', "
                f"but got '{self.primary_provider}'."
            )

        # -------------------------
        # Resolve fallback config
        # -------------------------
        fallback_cfg = self.llm_cfg.get("fallback") or {}

        # Fallback provider: prefer llm.fallback.provider, else legacy llm.fallback_provider
        self.fallback_provider: Optional[str] = (
            (fallback_cfg.get("provider") or self.llm_cfg.get("fallback_provider"))
        )
        self.fallback_provider = self.fallback_provider.lower() if self.fallback_provider else None

        # Fallback model: prefer llm.fallback.model, else legacy llm.fallback_model
        self.fallback_model: Optional[str] = (
            fallback_cfg.get("model")
            or self.llm_cfg.get("fallback_model")
        )

        # Gemini key – multiple locations supported
        self.gemini_api_key: Optional[str] = (
            fallback_cfg.get("api_key")
            or self.llm_cfg.get("gemini_api_key")
            or self.secrets_cfg.get("gemini_api_key")
            or os.environ.get("GEMINI_API_KEY")
        )

        if self.fallback_provider == "google":
            if not self.fallback_model:
                log.warning(
                    "LLMClient: fallback provider is Google but no fallback.model configured."
                )
            if not self.gemini_api_key:
                log.warning(
                    "LLMClient: fallback provider is Google but no API key found. "
                    "Set one of:\n"
                    " - llm.fallback.api_key\n"
                    " - llm.gemini_api_key\n"
                    " - secrets.gemini_api_key\n"
                    " - GEMINI_API_KEY environment variable"
                )
            else:
                log.info(
                    "LLMClient: Gemini fallback configured with model '%s'.",
                    self.fallback_model,
                )
        elif self.fallback_provider:
            log.warning(
                "LLMClient: unsupported fallback.provider '%s' – "
                "only 'google' is implemented currently.",
                self.fallback_provider,
            )

    # ------------------------------------------------------------------
    # Public method used by internal/external APIs
    # ------------------------------------------------------------------
    def chat(self, messages: List[Dict[str, str]], temperature: float = 0.2) -> str:
        """
        messages = [
          {"role": "system", "content": "..."},
          {"role": "user", "content": "..."},
          ...
        ]
        """
        # --- Try primary first (OpenAI) ---
        try:
            return self._call_openai(messages, temperature)
        except Exception as e:
            log.error("LLM primary (OpenAI) failed: %s", e, exc_info=True)

        # --- Try fallback (Gemini or others) ---
        if self.fallback_provider == "google" and self.fallback_model and self.gemini_api_key:
            try:
                return self._call_gemini(messages, temperature)
            except Exception as e:
                log.error("LLM fallback (Gemini) failed: %s", e, exc_info=True)

        # If no fallback or everything failed
        return "Sorry, I’m having trouble reaching the language models right now."

    # ------------------------------------------------------------------
    # OpenAI (primary)
    # ------------------------------------------------------------------
    def _call_openai(self, messages: List[Dict[str, str]], temperature: float) -> str:
        """
        Call OpenAI Chat Completions API using the official SDK.
        """
        resp = self.openai_client.chat.completions.create(
            model=self.primary_model,
            messages=messages,
            temperature=temperature,
        )
        if not resp.choices:
            raise RuntimeError("OpenAI returned no choices.")
        return resp.choices[0].message.content

    # ------------------------------------------------------------------
    # Gemini (fallback via REST)
    # ------------------------------------------------------------------
    def _call_gemini(self, messages: List[Dict[str, str]], temperature: float) -> str:
        # Call Gemini using the official SDK (more stable than hand-crafted REST URLs).
       
        try:
            import google.genai as genai
        except Exception as e:
            log.error("Gemini SDK import failed: %s", e, exc_info=True)
            return "Sorry, fallback LLM is not available (Gemini SDK missing)."


        # Flatten messages into a single prompt (keep your existing behavior)
        system_parts: List[str] = []
        user_parts: List[str] = []

        for m in messages:
            role = (m.get("role") or "").lower()
            content = m.get("content", "")
            if role == "system":
                system_parts.append(content)
            else:
                user_parts.append(content)

        prompt = ""
        if system_parts:
            prompt += "SYSTEM:\n" + "\n".join(system_parts) + "\n\n"
        if user_parts:
            prompt += "USER:\n" + "\n".join(user_parts)

        # Create client
        client = genai.Client(api_key=self.gemini_api_key)

        # IMPORTANT: Keep model in one place; allow env override later if you want
        model = self.fallback_model or "gemini-flash-latest"

        # Temperature config (SDK supports config object)
        try:
            resp = client.models.generate_content(
                model=model,
                contents=prompt,
                # Some SDK versions support config=..., keep it minimal if unsure
            )
            # resp.text is the standard convenience accessor
            return (resp.text or "").strip() or "Sorry, I couldn't generate a response."
        except Exception as e:
            # Never print the key; log only the error
            log.error("Gemini SDK call failed: %s", e, exc_info=True)
            return "Sorry, I’m having trouble reaching the language models right now."
