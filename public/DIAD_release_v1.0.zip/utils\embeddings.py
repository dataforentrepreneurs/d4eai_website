"""Create a reusable embedder for “query embeddings” (HF 384)"""
from __future__ import annotations

from typing import List

def build_query_embedder(cfg):
    """
    Returns a function embed(texts: List[str]) -> List[List[float]]
    Uses the same provider config as Phase 8 for document_rag.
    """
    doc_rag = cfg.get("document_rag", {}) or {}
    provider = (doc_rag.get("embedding_provider") or "huggingface").lower()

    # HF / Local
    if provider in ("huggingface", "local"):
        from sentence_transformers import SentenceTransformer

        model_name = doc_rag.get("huggingface_model", "sentence-transformers/all-MiniLM-L6-v2")
        model = SentenceTransformer(model_name)

        def embed(texts: List[str]) -> List[List[float]]:
            vecs = model.encode(texts, convert_to_numpy=False)
            return [v.tolist() if hasattr(v, "tolist") else list(v) for v in vecs]

        return embed

    # If later you re-enable Gemini/OpenAI, you can extend here
    raise ValueError(f"Unsupported embedding_provider for document_rag: {provider}")
