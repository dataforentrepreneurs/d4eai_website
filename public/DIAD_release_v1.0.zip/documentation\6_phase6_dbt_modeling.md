# DIAD Phase 6A — dbt Modeling Layer

This phase transforms raw operational tables into structured data warehouse layers (Staging → Canonical → Marts) using dbt (data build tool), ensuring strict schema tests and data sanity.

---

## 1. dbt Project Folder Layout

The project models, macros, and profiles are stored under:
```
dbt/
  diad_dbt/
    models/
      staging/        # Cleans and formats raw tables
      canonical/      # Unified client objects (customers, orders, products)
      marts/          # Structured tables optimized for BI and chatbots
    dbt_project.yml
  profiles/
    profiles.yml      # Connection profiles for BigQuery
```

---

## 2. Ingestion Orchestrator Script

We manage dbt execution through a wrapper script `scripts/6_1_run_dbt.py`. 
This script runs the dbt CLI inside the python virtual environment and handles profile authentication automatically.

---

## 3. Run Commands

You can run dbt builds using the runner script:

```powershell
# Run full modeling run (staging + canonical + marts + tests)
python scripts/6_1_run_dbt.py --mode full

# Run specific modeling layers
python scripts/6_1_run_dbt.py --mode staging
python scripts/6_1_run_dbt.py --mode canonical
python scripts/6_1_run_dbt.py --mode marts

# Run data quality tests only
python scripts/6_1_run_dbt.py --mode test
```

---

## 4. Lineage and Acceptance Criteria

At the end of a successful dbt run:
- All dbt tests (unique, not_null, relationship checks) must be **green**.
- BigQuery schemas in `ecommerce_canonical` and `ecommerce_mart` datasets are generated as modeled tables/views.
- These modeled views are ready to be queried by downstream chatbot prep scripts (Phase 7).
