# DIAD — AI-Powered Data Intelligence for Entrepreneurs

> **Turn your store's raw data into an AI chatbot that knows everything about your business — deployed in under 30 minutes, running entirely inside your own Google Cloud account.**

DIAD (Data Intelligence & Analytics Dashboard) is an end-to-end data warehouse and AI chatbot platform built specifically for e-commerce entrepreneurs. It connects to your Google Drive documents, Notion pages, Firestore orders, and Google Analytics — then deploys a private AI assistant that can answer questions about your customers, orders, policies, and operations.

---

## 🚀 Get Started in 60 Seconds

### Prerequisites
- **Windows 10/11** (the setup script handles everything else automatically)
- **A Google Cloud account** (free tier is sufficient — [sign up here](https://console.cloud.google.com/))

### One-Line Setup (PowerShell)

```powershell
iwr "https://download.diad.d4e.ai/DIAD_release_v1.0.zip" -OutFile "$env:TEMP\DIAD.zip"; Expand-Archive "$env:TEMP\DIAD.zip" -DestinationPath "$home\DIAD" -Force; Remove-Item "$env:TEMP\DIAD.zip"; cd "$home\DIAD"; .\setup.ps1
```
```powershell
Remove-Item "$home\DIAD" -Recurse -Force -ErrorAction SilentlyContinue; iwr "https://download.diad.d4e.ai/DIAD_release_v1.0.zip?v=2" -OutFile "$env:TEMP\DIAD.zip"; Expand-Archive "$env:TEMP\DIAD.zip" -DestinationPath "$home\DIAD" -Force; Remove-Item "$env:TEMP\DIAD.zip"; cd "$home\DIAD"; .\setup.ps1
```
**That's it.** The script will automatically:
- ✅ Download the encrypted DIAD release package
- ✅ Install Python 3.11 (if not already installed)
- ✅ Install Google Cloud SDK (for deployment)
- ✅ Create virtual environment & dependencies
- ✅ Open the onboarding dashboard in your browser (`http://localhost:8000`)


---

## 🖥️ What Happens Next

Once the dashboard opens at `http://localhost:8000`, you'll follow a guided wizard:

| Step | What You Do | What DIAD Does |
|------|------------|----------------|
| **1. GCP Setup** | Create a Google Cloud project & upload your service account key | Auto-configures your deployment credentials |
| **2. Link Sources** | Share your Google Drive folders & connect Notion | Sets up document access for the AI |
| **3. API Keys** | Enter your OpenAI & Pinecone keys | Securely vaults them in your GCP Secret Manager |
| **4-8. Pipeline** | Click "Run" on each step | Builds your data warehouse & deploys your chatbot |

An interactive **Onboarding Mentor** guides you through every step with plain-English instructions.

---

## 🔒 Your Data Stays Yours

> **Everything runs on YOUR machine and YOUR Google Cloud account.**

| Component | Where It Lives |
|-----------|---------------|
| Onboarding Dashboard | Your local machine (`localhost:8000`) |
| Service Account Keys | Your machine (`keys/` folder) |
| API Keys (OpenAI, Pinecone) | Your GCP Secret Manager |
| Database (BigQuery) | Your GCP Project |
| AI Chatbot (Cloud Run) | Your GCP Project |
| Documents (Drive, Notion) | Your existing accounts |

No intermediary servers. No data sharing. You have 100% ownership and control.

---

## 📦 What's Inside

```
DIAD/
├── setup.ps1                    ← One-click setup script
├── scripts/
│   ├── onboarding_dashboard.py  ← The onboarding wizard server
│   ├── 1_*.py                   ← GCP bootstrap scripts
│   ├── phase3/                  ← Data ingestion pipeline
│   ├── phase7/                  ← Chatbot data preparation
│   ├── phase8/                  ← Vector database sync
│   └── phase9/                  ← Cloud Run deployment
├── chatbot/
│   ├── external_api.py          ← Customer-facing chatbot API
│   └── internal_api.py          ← Admin chatbot API
├── dbt/                         ← Data transformation models
├── config/                      ← Project configuration
├── keys/                        ← Service account keys (gitignored)
└── documentation/               ← Detailed technical guides
```

---

## 💼 Licensing

DIAD is a commercial product by [DataForEntrepreneurs](https://github.com/dataforentrepreneurs). The source code is provided for transparency and self-hosted deployment. Usage is subject to the license terms included in this repository.

For enterprise licensing, custom integrations, or managed deployment, contact: **dataforentrepreneurs@gmail.com**

---

## 🛠️ For Developers

<details>
<summary>Manual Setup (without the setup script)</summary>

```powershell
# 1. Clone
git clone https://github.com/dataforentrepreneurs/DIAD_Agent.git
cd DIAD_Agent

# 2. Virtual environment
python -m venv venv_dbt
.\venv_dbt\Scripts\activate

# 3. Install dependencies (lightweight for dashboard only)
pip install -r requirements_onboarding.txt

# 4. Launch
python scripts/onboarding_dashboard.py
# → Open http://localhost:8000
```

For the full ML pipeline (torch, sentence-transformers), install the complete requirements:
```powershell
pip install -r requirements.txt
```

</details>

<details>
<summary>Architecture Documentation</summary>

See the `documentation/` folder for detailed guides:
- [Architecture Overview](documentation/0_diad_architecture.md)
- [GCP Onboarding](documentation/1_client_gcp_onboarding.md)
- [Self-Serve Architecture](documentation/12_self_serve_architecture.md)
- [Automated Onboarding Guide](documentation/13_automated_onboarding_guide.md)

</details>