# Self-Serve Automated Client Onboarding Guide

This guide describes how to run and use the fully automated **DIAD Onboarding Portal** and **Interactive Guide Bot**. This tool allows clients to onboard themselves, execute environment diagnostics, write configuration settings, and deploy the DIAD data warehouse and chatbot directly inside their own Google Cloud account without requiring an active Integration Admin.

---

## 1. Overview of the Automated Workflow

The onboarding workflow is designed to run **entirely inside the client's ecosystem** to ensure complete security, privacy, and data ownership. 

```
[Client Machine]
 └── python scripts/onboarding_dashboard.py (Local Daemon)
      └── Serves: http://localhost:8000 (UI Portal)
           ├── Writes: config/client_rawdata.json
           ├── Saves: keys/client-service-account.json
           ├── Executes: Local Python & PowerShell pipeline scripts
           └── Hosts: Onboarding Guide Bot (Context-aware assistant)
```

The admin is only notified (escalated) when the client is explicitly stuck and requests assistance.

---

## 2. Prerequisites for the Client

Before running the onboarding portal, the client must have the following installed on their machine:
1. **Python 3.9+** (added to environment PATH).
2. **Google Cloud SDK (gcloud CLI)**: Required for provisioning GCP permissions and configuring GCP Secret Manager keys.
3. **Virtual Environment**: Run within an active Python virtual environment containing the requirements of the project.

---

## 3. How to Launch and Use the Portal

### Step 1: Start the Local Daemon
Open a terminal in the root of the `diad` directory, activate the project's virtual environment, and run:
```powershell
# Activate virtual environment (Windows)
.\venv_dbt\Scripts\activate

# Start the onboarding daemon
python scripts/onboarding_dashboard.py
```

### Step 2: Open the Dashboard
Open your web browser and navigate to:
```
http://localhost:8000
```
This loads the **Self-Serve Onboarding Portal** served directly from the local daemon.

### Step 3: Complete the Onboarding Wizard

1. **Store Details**: Enter the business/store name and main website URL.
2. **Connections & Sources**: 
   - Google Drive Folder IDs and Notion Parent Page IDs.
   - Google Analytics (GA4) Property ID and Measurement ID.
   - Private keys (OpenAI Key, Pinecone Key, Notion Integration Token, Confluence Token). These keys are uploaded directly to **your own GCP Secret Manager** and are never sent to external servers.
   - Click **Save Config & Continue**.
3. **Credentials & Diagnostics**:
   - Drag and drop or browse to select your **GCP Service Account JSON Key** file.
   - The portal will run local diagnostics verifying that your Python version, Google Cloud CLI, virtual environment, and config are correctly set up.
4. **Run Pipeline Steps**:
   - Click the **Run** button on each pipeline step.
   - Steps execute sequentially: validating the GCP connection, enabling APIs, bootstrapping BigQuery datasets, ingesting CSV transaction data, building dbt models, and deploying the chatbot container to Google Cloud Run.
   - View live terminal output logs directly in the scrolling window.
5. **Success & Embed**:
   - Once all steps show green checks, copy the copyable Javascript embed script to deploy the chatbot on your store's website.

---

## 4. Interactive Troubleshooting Bot

The panel on the right side of the screen is your **DIAD Onboarding Guide Bot**.
* **Context-Aware Assistance**: The bot monitors your diagnostic parameters and checks for failed scripts. If a step fails, the bot reads the terminal logs, isolates the error (e.g., missing gcloud, deactivated billing, or insufficient service account permissions), and explains it in simple terms.
* **Security & Privacy Reassurance**: If asked, the bot explains that all keys, datasets, and scripts run on your own machine and cloud account.
* **Escalate to Admin**: If you are stuck on a technical error, click the **Request Human Admin Assistance** button. This flags the local server, logs a screaming alert, and simulates a notification to the support team so a DIAD Integration Admin can step in and help.

---

## 5. Security Architecture (Why Your Data is Secure)

> [!IMPORTANT]
> To ensure clients do not feel scared that their data is leaving their ecosystem, the onboarding portal operates under these security guidelines:

* **Direct Integration**: The local daemon connects directly from the client's machine to the client's Google Cloud project. No third-party servers act as intermediaries.
* **Local Credentials**: The Service Account Key is uploaded to `/keys/` on the client's machine and is used exclusively by the local terminal runner to authenticate API requests to the client's Google Cloud Project.
* **Encrypted Secrets**: Private API keys (OpenAI, Pinecone) are uploaded directly into GCP Secret Manager inside the client's project using the `gcloud secrets` CLI. They are never saved in cleartext inside code repositories.
* **Private Resources**: The BigQuery datasets, Google Cloud Storage buckets, and Cloud Run Docker containers are all created inside the client's own billing account, giving them 100% ownership over their data.
