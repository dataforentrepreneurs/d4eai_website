# chatbot/external_api.py
"""
External chatbot API (customer-facing) – direct BigQuery mode.

Cloud Run safe:
- No import-time dependency on config values
- Lifespan loads raw config using bq_utils.load_raw_config()
- Uses get_client_cfg(raw_cfg) for client-specific values
- Uses build_bq_client(raw_cfg) (NOT client_cfg)
- PROJECT_ID comes from client_cfg["project_id"] (NOT env var)

Run local:
  python -m uvicorn chatbot.external_api:app --reload --port 8002

gcloud run services update diad-external-chat `
  --region=asia-southeast1 `
  --set-env-vars EXPOSE_DEBUG_SQL=true
 
Example request:
{
  "question": "Where is my order ORD-100045?",
  "email": "diya.ghosh@shopmail.com",
  "order_number": "ORD-100045"
}
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple
from decimal import Decimal
from datetime import datetime, date
import json
import logging
import re
import sys
import os

from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .bq_utils import build_bq_client, load_raw_config, get_client_cfg
from .llm_client import LLMClient
from .rag_docs import query_docs, DocChunk, preload_hf_model
from fastapi import APIRouter
import importlib


from dotenv import load_dotenv
load_dotenv(".env.local")

preload_hf_model()

# -----------------------------
# Logging
# -----------------------------
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
    stream=sys.stdout,
)

# -----------------------------
# Globals (initialized in lifespan)
# -----------------------------
raw_cfg: Optional[dict] = None
client_cfg: Optional[dict] = None
bq_client = None
llm: Optional[LLMClient] = None

PROJECT_ID: Optional[str] = None
MART_DATASET: Optional[str] = None
CANONICAL_DATASET: Optional[str] = None
EXPOSE_DEBUG_SQL = os.getenv("EXPOSE_DEBUG_SQL", "false").lower() == "true"

def _require_ready() -> None:
    if not (raw_cfg and client_cfg and bq_client and llm and PROJECT_ID and MART_DATASET and CANONICAL_DATASET):
        raise RuntimeError("Service not initialized yet (lifespan has not completed).")


def _cfg_warehouse_get(key: str, default: Optional[str] = None) -> Optional[str]:
    """
    Your client config uses:
      warehouse.canonical_dataset
      warehouse.marts_dataset
    But we allow fallbacks to avoid small config drift.
    """
    wh = (client_cfg or {}).get("warehouse") or {}
    return wh.get(key) or default


def _cfg_ingest_get(path_key: str):
    try:
        return client_cfg.get("ingest", {}).get("datasets", {}).get(path_key)
    except Exception:
        return None
    
@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Startup:
      - load raw config (supports both raw.client and raw.clients[CLIENT_ID])
      - derive client_cfg
      - set datasets and project
      - create BigQuery + LLM clients
    """
    global raw_cfg, client_cfg, bq_client, llm
    global PROJECT_ID, MART_DATASET, CANONICAL_DATASET

    logger.info("=== DIAD External Chatbot starting ===")

    # ✅ Load raw config using helper (path-safe in Cloud Run)
    raw_cfg = load_raw_config()
    client_cfg = get_client_cfg(raw_cfg)

    runtime_cfg = raw_cfg.get("runtime", {})
    if "expose_debug_sql" in runtime_cfg:
        os.environ["EXPOSE_DEBUG_SQL"] = str(runtime_cfg["expose_debug_sql"]).lower()


    # ✅ Project ID comes from client config (not env vars)
    PROJECT_ID = client_cfg.get("project_id")
    if not PROJECT_ID:
        raise RuntimeError("client.project_id missing in client_rawdata.json")

    # ✅ Dataset names from client config
    CANONICAL_DATASET = _cfg_warehouse_get("canonical_dataset") or _cfg_warehouse_get("canonical") or "ecommerce_canonical"
    #MART_DATASET = _cfg_warehouse_get("marts_dataset") or _cfg_warehouse_get("mart_dataset") or "ecommerce_mart"
    MART_DATASET = (
        _cfg_warehouse_get("marts_dataset")
        or _cfg_warehouse_get("mart_dataset")
        or _cfg_ingest_get("mart")
        or "ecommerce_mart"
    )

    # ✅ BigQuery client: pass RAW config (not client_cfg)
    bq_client = build_bq_client(raw_cfg)

    # ✅ LLM client: pass RAW config (it reads llm + secrets etc.)
    llm = LLMClient(raw_cfg)

    yield

    logger.info("🛑 DIAD External Chatbot shutdown complete")


# ✅ Load raw config at import time for CORS setup
_origins = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://localhost:5173",
    "http://localhost:8000",
]
try:
    _raw = load_raw_config()
    _client_cfg = get_client_cfg(_raw)
    _web_url = _client_cfg.get("website_url")
    if _web_url:
        _origins.append(_web_url.rstrip("/"))
        if "://" in _web_url and "://www." not in _web_url:
            _parts = _web_url.split("://")
            _origins.append(f"{_parts[0]}://www.{_parts[1]}".rstrip("/"))
except Exception:
    pass

app = FastAPI(
    title="DIAD External Chatbot API",
    version="0.3.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/debug/deps")
def debug_deps():
    out = {}
    for mod in ["google.genai", "google", "openai"]:
        try:
            importlib.import_module(mod)
            out[mod] = "OK"
        except Exception as e:
            out[mod] = f"FAIL: {type(e).__name__}: {e}"
    return out

@app.get("/")
def root():
    return {"status": "ok", "service": "DIAD external chatbot"}

class ExternalChatRequest(BaseModel):
    question: str
    email: Optional[str] = None
    order_number: Optional[str] = None
    uid: Optional[str] = None

class ExternalChatResponse(BaseModel):
    answer: str
    intent: Optional[str] = None
    sql: Optional[str] = None
    orders_preview: Optional[List[Dict[str, Any]]] = None
    docs_used: Optional[List[str]] = None

def make_jsonable(obj: Any) -> Any:
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, list):
        return [make_jsonable(x) for x in obj]
    if isinstance(obj, dict):
        return {k: make_jsonable(v) for k, v in obj.items()}
    return obj

_DROP_KEYS_EXACT = {
    "email", "phone", "phone_number", "customer_id_bk", "customer_sk", "identity_sk", "uid",
    "full_name", "first_name", "last_name", "given_name", "family_name",
    "address_line1", "address_line2", "address1", "address2", "street", "street1", "street2",
    "card_number", "card_last4", "card_brand", "cardholder_name",
    "payment_method_id", "payment_token", "paypal_id",
}

_DROP_KEYS_CONTAINS = [
    "email", "phone", "mobile", "whatsapp", "contact", "address",
    "card", "iban", "account_number", "routing", "pan", "cvv",
]


def _key_is_pii(key: str) -> bool:
    kl = key.lower()
    if kl in _DROP_KEYS_EXACT:
        return True
    return any(sub in kl for sub in _DROP_KEYS_CONTAINS)


def strip_pii(obj: Any) -> Any:
    if isinstance(obj, dict):
        cleaned: Dict[str, Any] = {}
        for k, v in obj.items():
            if _key_is_pii(k):
                continue
            cleaned[k] = strip_pii(v)
        return cleaned
    if isinstance(obj, list):
        return [strip_pii(x) for x in obj]
    return obj


def fetch_external_docs(question: str, top_k: int = 5) -> List[DocChunk]:
    try:
        return query_docs(
            question,
            top_k=top_k,
            filter={"visibility": "external"},
        )
    except Exception as e:
        logger.exception("Error querying external docs RAG: %s", e)
        return []


def classify_external_intent(question: str) -> str:
    q = " ".join((question or "").lower().split())

    if "where is my order" in q:
        return "where_is_my_order"
    if "track my order" in q or "tracking my order" in q or "tracking number" in q:
        return "where_is_my_order"
    if "where" in q and "order" in q and "my" in q:
        return "where_is_my_order"

    if "status of my last order" in q or "status of my recent order" in q:
        return "last_order_status"
    if ("last order" in q or "recent order" in q) and "status" in q:
        return "last_order_status"

    if "status of my order" in q:
        return "order_status"
    if "status" in q and "order" in q:
        return "order_status"

    if "my orders" in q or "order history" in q or "past orders" in q:
        return "order_history_self"
    if "show all my orders" in q or "show my orders" in q:
        return "order_history_self"

    if "how many times" in q and ("ordered" in q or "orders" in q or "order" in q):
        return "order_count_self"

    if "how much have i spent" in q or "how much i spent" in q or "total spend" in q:
        return "orders_spend_self"

    if "where is my refund" in q or "status of my refund" in q or "refund status" in q:
        return "refund_status"

    return "generic_support"


def _sanitize_literal(value: str) -> str:
    if value is None:
        return ""
    return value.replace("`", "").replace("'", "\\'")


def extract_order_number_from_question(question: str) -> Optional[str]:
    q = (question or "")
    m = re.search(r"(ord-\d+)", q, re.IGNORECASE)
    if m:
        return m.group(1).upper()

    m2 = re.search(r"order\s+[#:]?\s*([a-z0-9\-]+)", q, re.IGNORECASE)
    if m2:
        return m2.group(1)
    return None


def _build_order_dossier_table() -> str:
    _require_ready()
    return f"`{PROJECT_ID}.{MART_DATASET}.order_dossier_tbl`"


def _build_customer360_table() -> str:
    _require_ready()
    return f"`{PROJECT_ID}.{MART_DATASET}.customer_360_tbl`"


def fetch_orders_by_order_number(order_number: str, limit: int = 5) -> Tuple[str, List[Dict[str, Any]]]:
    _require_ready()
    order_number_safe = _sanitize_literal(order_number)
    table = _build_order_dossier_table()

    sql = f"""
    SELECT *
    FROM {table}
    WHERE order_number = '{order_number_safe}'
    ORDER BY order_datetime DESC
    LIMIT {int(limit)}
    """
    logger.info("External fetch_orders_by_order_number SQL:\n%s", sql)
    job = bq_client.query(sql)
    rows = [make_jsonable(dict(r)) for r in job.result()]
    return sql, rows


def fetch_orders_by_email(email: str, limit: int = 10) -> Tuple[str, List[Dict[str, Any]]]:
    _require_ready()
    email_safe = _sanitize_literal(email).lower()
    orders_tbl = _build_order_dossier_table()
    cust_tbl = _build_customer360_table()

    sql = f"""
    SELECT o.*
    FROM {orders_tbl} AS o
    JOIN {cust_tbl} AS c
      ON o.customer_sk = c.customer_sk
    WHERE LOWER(c.email) = '{email_safe}'
    ORDER BY o.order_datetime DESC
    LIMIT {int(limit)}
    """
    logger.info("External fetch_orders_by_email SQL:\n%s", sql)
    job = bq_client.query(sql)
    rows = [make_jsonable(dict(r)) for r in job.result()]
    return sql, rows


def fetch_orders_by_uid(uid: str, limit: int = 10) -> Tuple[str, List[Dict[str, Any]]]:
    _require_ready()
    uid_safe = _sanitize_literal(uid)
    orders_tbl = _build_order_dossier_table()
    bridge_tbl = f"`{PROJECT_ID}.{CANONICAL_DATASET}.bridge_identity_customer`"
    identity_tbl = f"`{PROJECT_ID}.{CANONICAL_DATASET}.dim_identity_account`"

    sql = f"""
    WITH cust AS (
      SELECT bic.customer_sk
      FROM {bridge_tbl} AS bic
      JOIN {identity_tbl} AS dia
        ON bic.identity_sk = dia.identity_sk
      WHERE dia.uid = '{uid_safe}'
    )
    SELECT o.*
    FROM {orders_tbl} AS o
    JOIN cust ON o.customer_sk = cust.customer_sk
    ORDER BY o.order_datetime DESC
    LIMIT {int(limit)}
    """
    logger.info("External fetch_orders_by_uid SQL:\n%s", sql)
    job = bq_client.query(sql)
    rows = [make_jsonable(dict(r)) for r in job.result()]
    return sql, rows


def answer_with_llm(
    question: str,
    intent: str,
    orders: List[Dict[str, Any]],
    doc_chunks: Optional[List[DocChunk]] = None,
) -> str:
    _require_ready()
    doc_chunks = doc_chunks or []

    if not orders and not doc_chunks:
        if intent in ("where_is_my_order", "order_status", "refund_inquiry", "cancel_order"):
            return (
                "I could not find any matching orders or relevant help articles for your question. "
                "Please double-check your details or contact support."
            )

    max_orders_for_llm = 5
    orders_for_llm = orders[:max_orders_for_llm]
    sanitized_orders = [strip_pii(o) for o in orders_for_llm]

    doc_lines = []
    for i, chunk in enumerate(doc_chunks, start=1):
        source = chunk.source or "unknown"
        doc_id = chunk.doc_id or ""
        doc_lines.append(
            f"[DOC {i} | source={source} | id={doc_id} | score={chunk.score:.3f}]\n{chunk.text}\n"
        )
    doc_context = "\n\n".join(doc_lines) if doc_lines else "No external docs were retrieved for this question."

    biz_name = client_cfg.get("business_name", "our store")
    system_prompt = (
        f"You are a customer support assistant for {biz_name}.\n\n"
        "Rules:\n"
        "- Use the order JSON and doc context provided where possible.\n"
        "- Do NOT invent client-specific tracking events, statuses, or dates for actual orders.\n"
        "- If general customer help documentation is missing from the context, leverage your general knowledge to provide a friendly, helpful, and standard industry-best-practice customer support response (e.g. general return guidelines, standard ecommerce packing and shipping practices). Do NOT output any disclaimers, notes, or meta-announcements stating that specific files or help documents were not found in the search context.\n"
        "- Do NOT mention email addresses, phone numbers, or exact postal addresses.\n"
        "- Do not mention SQL, BigQuery, Pinecone, or internal systems.\n"
        "- Be friendly and concise.\n"
    )

    user_content = (
        f"Customer question:\n{question}\n\n"
        f"Detected intent: {intent}\n\n"
        f"Order context (sanitized JSON):\n{json.dumps(sanitized_orders, ensure_ascii=False)}\n\n"
        f"[DOC CONTEXT]\n{doc_context}\n\n"
        "Answer using the context above where possible. If specific details are missing, provide a generic and best-practice customer-facing answer."
    )

    try:
        ans = llm.chat(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content},
            ],
            temperature=0.2,
        )
        return (ans or "").strip() or "Sorry — I couldn’t prepare an answer right now. Please try again."
    except Exception as e:
        logger.exception("LLM error (external): %s", e)
        return "Sorry — I’m having trouble preparing the answer right now. Please try again."


@app.post("/external/chat", response_model=ExternalChatResponse)
def external_chat(req: ExternalChatRequest) -> ExternalChatResponse:
    _require_ready()

    question = req.question
    email = req.email
    order_number = req.order_number
    uid = req.uid

    intent = classify_external_intent(question)

    if not order_number:
        parsed = extract_order_number_from_question(question)
        if parsed:
            order_number = parsed

    sql_used: Optional[str] = None
    orders: List[Dict[str, Any]] = []

    if order_number:
        try:
            sql_used, orders = fetch_orders_by_order_number(order_number, limit=5)
        except Exception as e:
            logger.exception("Error fetching by order_number: %s", e)
            raise HTTPException(status_code=500, detail="Error while looking up your order by order number.")

    elif email:
        try:
            sql_used, orders = fetch_orders_by_email(email, limit=10)
        except Exception as e:
            logger.exception("Error fetching by email: %s", e)
            raise HTTPException(status_code=500, detail="Error while looking up your orders by email.")

    elif uid:
        try:
            sql_used, orders = fetch_orders_by_uid(uid, limit=10)
        except Exception as e:
            logger.exception("Error fetching by uid: %s", e)
            raise HTTPException(status_code=500, detail="Error while looking up your orders by account ID.")

    else:
        return ExternalChatResponse(
            answer=(
                "To help you, please provide either:\n"
                "- The email address you used when placing the order, or\n"
                "- Your order number (e.g. ORD-123)."
            ),
            intent=intent,
            sql=None,
            orders_preview=None,
        )

    if not orders:
        if order_number:
            msg = (
                f"I couldn't find any order with the number '{order_number}'. "
                "Please double-check the number or provide the email address you used."
            )
        elif email:
            msg = (
                f"I couldn't find any orders linked to '{email}'. "
                "Please check the spelling or try with your order number."
            )
        else:
            msg = (
                "I couldn't find any orders based on the information provided. "
                "Please double-check your details or try a different email/order number."
            )

        #return ExternalChatResponse(answer=msg, intent=intent, sql=sql_used, orders_preview=None)
        return ExternalChatResponse(
            answer=msg,
            intent=intent,
            sql=sql_used if EXPOSE_DEBUG_SQL else None,
            orders_preview=None,
        )


    pinecone_key = os.getenv("PINECONE_API_KEY")
    if not pinecone_key:
        logger.info("External: skipping docs RAG (no PINECONE_API_KEY).")
        doc_chunks = []
    else:
        doc_chunks = []
        try:
            doc_chunks = fetch_external_docs(question, top_k=5)
        except Exception as e:
            logger.exception("External docs RAG failed (continuing without docs): %s", e)
            doc_chunks = []


    logger.info(
        "external_chat | intent=%s has_sql=%s orders=%d doc_chunks=%d",
        intent,
        bool(sql_used),
        len(orders),
        len(doc_chunks),
    )


    answer = answer_with_llm(
        question=question,
        intent=intent,
        orders=orders,
        doc_chunks=doc_chunks,
    )

    sanitized_preview = [strip_pii(o) for o in orders[:3]]

    return ExternalChatResponse(
        answer=answer,
        intent=intent,
        sql=sql_used if EXPOSE_DEBUG_SQL else None,
        orders_preview=sanitized_preview,
        docs_used=[c.doc_id or "" for c in doc_chunks] if doc_chunks else None,
    )