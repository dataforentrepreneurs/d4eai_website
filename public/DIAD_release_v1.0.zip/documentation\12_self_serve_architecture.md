# Self-Serve Zero-Human-Interaction Onboarding Blueprint

This blueprint outlines the technical roadmap to convert the current developer-led onboarding process into a fully automated, self-serve SaaS onboarding platform where clients configure their own integrations in under 5 minutes.

---

## 1. Current State vs. Future Self-Serve State

| Component | Current MVP (Developer-Led) | Target (Fully Self-Serve) |
| :--- | :--- | :--- |
| **Integrations Input** | Configured in `client_rawdata.json` | Web Portal forms (React / Next.js UI) |
| **GCP Project Setup** | Manual GCP console project creation | Automated via GCP Resource Manager API |
| **Credential Sharing** | Manual token copying & Secret Manager CLI | Secure OAuth 2.0 button clicks |
| **Google Analytics** | Client manually configures GA4 → BQ link | Programmatic linking via Analytics Admin API |
| **Trigger Pipeline** | Developer runs scripts in local terminal | Webhook calls backend API → Cloud Run Job |

---

## 2. High-Level System Architecture

```mermaid
sequenceDiagram
    actor Client as Store Owner (Client)
    participant UI as Onboarding Portal (Next.js)
    participant API as DIAD Core API (FastAPI)
    participant GCP as Google Cloud APIs
    participant Notion as Notion API (OAuth)
    participant Pinecone as Pinecone Vector DB

    Client->>UI: 1. Sign in & enter website URL
    UI->>API: POST /api/register
    API->>GCP: 2. Auto-provision GCP Project & GCS bucket
    GCP-->>API: Project & Bucket created

    Client->>UI: 3. Click "Connect Google Drive"
    UI->>GCP: Redirects to Google OAuth
    GCP-->>API: Return OAuth Token (Drive Access)

    Client->>UI: 4. Click "Connect Notion"
    UI->>Notion: Redirects to Notion OAuth
    Notion-->>API: Return Notion Access Token

    API->>GCP: 5. Create GA4 property & Web Stream
    API->>GCP: 6. Setup GA4-to-BigQuery Linking
    
    API->>Pinecone: 7. Provision Vector Namespace
    API->>GCP: 8. Trigger Initial Sync Job (Cloud Run Job)
    API-->>UI: Onboarding Complete! Show widget embed snippet
    UI-->>Client: Copy HTML Widget Script
```

---

## 3. Core Automation Deliverables (How to Build It)

### Phase A: OAuth 2.0 for Document Integrations
* **Google Drive**: Implement the Google Picker API on the frontend. The client logs in, selects their Drive folder, and we save the OAuth `refresh_token` in Firestore.
* **Notion**: Implement the "Connect to Notion" OAuth button. Notion returns an `access_token` and the selected workspace page details directly to our backend callback URL.

### Phase B: Programmatic Google Analytics & BigQuery Ingestion
* **Analytics Admin API**: Use `google-analytics-admin` SDK to automate property creation:
  ```python
  from google.analytics.admin_v1alpha import AnalyticsAdminServiceClient
  client = AnalyticsAdminServiceClient()
  # Create Property -> Create DataStream -> Get Measurement ID
  ```
* **Automated BigQuery Link**: Link GA4 to BigQuery programmatically using the Admin API’s `create_big_query_link` method:
  ```python
  client.create_big_query_link(
      parent=f"properties/{property_id}",
      big_query_link={"project": f"projects/{client_project_id}"}
  )
  ```

### Phase C: Infrastructure Automation (Backend Orchestration)
* **Shared Cluster (Multi-Tenant) vs. Single Tenant**:
  - *Option 1 (Recommended)*: Use a single, shared GCP project (`diad-production`) where each client has their own isolated BigQuery datasets (`client_a_mart`, `client_b_mart`) and Pinecone namespaces (`client_a_docs`). This is **100x cheaper** and avoids complex IAM and project-creation overhead.
  - *Option 2*: Use the Resource Manager API to dynamically spawn a new GCP project for each client. This offers complete data isolation but requires high setup latency and complex organizational permissions.

---

## 4. Proposed Implementation Plan

If you want to transition to this model, we can deliver it in three stages:

1. **Stage 1 (Frontend Wireframes & API Scaffolding)**: Build the Next.js onboarding form and the FastAPI `/api/onboard` endpoints.
2. **Stage 2 (Notion/Drive OAuth Integration)**: Replace raw API keys with standard OAuth loops.
3. **Stage 3 (Deployment & Automation Test)**: Package the backend orchestrator and test complete zero-interaction onboarding.
