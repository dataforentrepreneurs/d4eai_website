# chatbot/rag_docs.py

from __future__ import annotations
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Dict, List, Optional
import logging
import os
import requests  # ✅ added (Gemini embeddings via REST)
import threading  # ✅ added (safe HF load)

from .bq_utils import load_raw_config, get_client_cfg

log = logging.getLogger(__name__)

EMBED_DIM_DEFAULT = 1536


@dataclass
class DocChunk:
    text: str
    score: float
    source: Optional[str] = None
    doc_id: Optional[str] = None
    metadata: Dict[str, Any] = None


# ----------------------------
# Config (lazy + safe)
# ----------------------------

@lru_cache()
def _cfg() -> Dict[str, Any]:
    """
    Load config lazily. Do NOT hard-fail at import time.
    Cloud Run must be able to boot even if RAG creds are missing,
    as long as the endpoint can still return a response (or degrade gracefully).
    """
    try:
        raw_cfg = load_raw_config()
        client_cfg = get_client_cfg(raw_cfg)
    except Exception as e:
        log.warning("rag_docs: failed to load raw config; will rely on env vars. error=%s", e)
        raw_cfg = {}
        client_cfg = {}

    doc_cfg: Dict[str, Any] = (raw_cfg.get("document_rag", {}) or {})

    pinecone_api_key = os.environ.get("PINECONE_API_KEY")
    index_name = doc_cfg.get("index_name") or os.environ.get("PINECONE_INDEX_NAME")

    embedding_provider = (doc_cfg.get("embedding_provider", "auto") or "auto").lower()

    # OpenAI embedding model (existing)
    embedding_model = doc_cfg.get("embedding_model", "text-embedding-3-small")

    # ✅ NEW: Gemini embedding model (REST)
    gemini_embedding_model = doc_cfg.get("gemini_embedding_model") or os.environ.get("GEMINI_EMBEDDING_MODEL") or "text-embedding-004"
    gemini_api_key = os.environ.get("GEMINI_API_KEY")

    # Fallback order (existing) - keep backwards compatible:
    # If user didn't specify, prefer Gemini before HF to avoid heavy local loads.
    fallback_order = doc_cfg.get("embedding_fallback_order")
    if not fallback_order:
        fallback_order = ["gemini", "huggingface", "local"]

    hf_model_name = doc_cfg.get("huggingface_model", "sentence-transformers/all-MiniLM-L6-v2")
    top_k = int(doc_cfg.get("top_k", 5))
    embed_dim = int(doc_cfg.get("embed_dim") or doc_cfg.get("dimension") or EMBED_DIM_DEFAULT)


    # OpenAI key resolution (existing: env only)
    openai_key = os.environ.get("OPENAI_API_KEY")

    return {
        "raw_cfg": raw_cfg,
        "client_cfg": client_cfg,
        "doc_cfg": doc_cfg,
        "PINECONE_API_KEY": pinecone_api_key,
        "PINECONE_INDEX_NAME": index_name,
        "EMBEDDING_PROVIDER": embedding_provider,          # openai | gemini | huggingface | local | auto
        "EMBEDDING_MODEL": embedding_model,               # OpenAI model
        "GEMINI_EMBEDDING_MODEL": gemini_embedding_model, # ✅ Gemini model
        "GEMINI_API_KEY": gemini_api_key,                 # ✅ Gemini key
        "FALLBACK_ORDER": fallback_order,
        "HF_MODEL_NAME": hf_model_name,
        "DEFAULT_TOP_K": top_k,
        "EMBED_DIM": embed_dim,
        "OPENAI_API_KEY": openai_key,
    }


def _require(value: Optional[str], name: str) -> str:
    if not value:
        raise RuntimeError(f"{name} missing. Set it via env var or client_rawdata config.")
    return value


# ----------------------------
# Pinecone (lazy import)
# ----------------------------

@lru_cache()
def get_pinecone_index():
    cfg = _cfg()
    api_key = _require(cfg["PINECONE_API_KEY"], "PINECONE_API_KEY")
    index_name = _require(cfg["PINECONE_INDEX_NAME"], "PINECONE_INDEX_NAME")

    # Lazy import so Cloud Run boot is fast
    from pinecone import Pinecone

    pc = Pinecone(api_key=api_key)
    return pc.Index(index_name)


# ----------------------------
# Embeddings (lazy import)
# ----------------------------

def _pad_or_truncate(vec, target_dim: int) -> List[float]:
    # Lazy import numpy (fast) only when needed
    import numpy as np

    arr = np.array(vec, dtype=float).reshape(-1)
    if arr.shape[0] == target_dim:
        return arr.tolist()
    if arr.shape[0] > target_dim:
        return arr[:target_dim].tolist()
    pad_len = target_dim - arr.shape[0]
    return np.pad(arr, (0, pad_len), mode="constant").tolist()


def _embed_openai(text: str) -> List[float]:
    cfg = _cfg()
    api_key = _require(cfg["OPENAI_API_KEY"], "OPENAI_API_KEY")
    model = cfg["EMBEDDING_MODEL"] or "text-embedding-3-small"

    # OpenAI SDK v1+ style
    from openai import OpenAI
    client = OpenAI(api_key=api_key)

    resp = client.embeddings.create(model=model, input=text)
    return resp.data[0].embedding


def _embed_gemini(text: str) -> List[float]:
    """
    ✅ Gemini embeddings via REST (no heavy SDK).
    Endpoint:
      POST https://generativelanguage.googleapis.com/v1beta/models/{model}:embedContent?key=...
    Response typical shape:
      { "embedding": { "values": [ ... ] } }
    """
    cfg = _cfg()
    api_key = _require(cfg["GEMINI_API_KEY"], "GEMINI_API_KEY")
    model = cfg["GEMINI_EMBEDDING_MODEL"] or "text-embedding-004"

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:embedContent"
    params = {"key": api_key}
    payload = {"content": {"parts": [{"text": text}]}}
    resp = requests.post(url, params=params, json=payload, timeout=30)
    resp.raise_for_status()
    data = resp.json()

    try:
        vec = data["embedding"]["values"]
        return _pad_or_truncate(vec, _cfg()["EMBED_DIM"])
    except Exception as e:
        log.error("Unexpected Gemini embed response format: %s | data=%s", e, data)
        raise


# HF model: thread-safe lazy singleton
_HF_LOCK = threading.Lock()
_HF_INSTANCE = None


@lru_cache()
def _hf_model_name() -> str:
    return _cfg()["HF_MODEL_NAME"]


def _hf_model():
    """
    Lazy-load SentenceTransformer once per container.
    NOTE: First call can still be heavy. Use preload_hf_model() at app startup
    to avoid request-time load causing 503s on Cloud Run.
    """
    global _HF_INSTANCE
    if _HF_INSTANCE is not None:
        return _HF_INSTANCE
    with _HF_LOCK:
        if _HF_INSTANCE is None:
            from sentence_transformers import SentenceTransformer
            name = _hf_model_name()
            log.info("rag_docs: loading HF model %s", name)
            _HF_INSTANCE = SentenceTransformer(name)
    return _HF_INSTANCE


def preload_hf_model() -> None:
    """
    ✅ Call this at FastAPI startup (recommended) so HF fallback is ready
    before the first request hits /external/chat.
    """
    try:
        _hf_model()
        log.info("rag_docs: HF model preloaded successfully")
    except Exception as e:
        log.warning("rag_docs: HF preload failed (will still try lazy load later). err=%s", e)


def _embed_hf_local(text: str) -> List[float]:
    cfg = _cfg()
    vec = _hf_model().encode(text)
    return _pad_or_truncate(vec, cfg["EMBED_DIM"])


def embed_with_fallback(text: str) -> List[float]:
    cfg = _cfg()
    provider = cfg["EMBEDDING_PROVIDER"]
    text = (text or "").strip()
    if not text:
        raise ValueError("Cannot embed empty text.")

    # Explicit provider modes
    if provider == "openai":
        return _embed_openai(text)

    if provider == "gemini":
        return _embed_gemini(text)

    if provider in {"huggingface", "local"}:
        return _embed_hf_local(text)

    # auto mode: OpenAI -> (fallback_order...)
    last_err: Optional[Exception] = None

    # Try OpenAI first if key exists
    if cfg.get("OPENAI_API_KEY"):
        try:
            return _embed_openai(text)
        except Exception as e:
            last_err = e
            log.warning("OpenAI embeddings failed, trying fallbacks. err=%s", e)

    # Fallbacks: now supports gemini + hf/local
    for prov in cfg["FALLBACK_ORDER"]:
        p = (prov or "").lower()
        try:
            if p == "gemini":
                # Only try if key exists; otherwise treat as skipped
                if cfg.get("GEMINI_API_KEY"):
                    return _embed_gemini(text)
                else:
                    raise RuntimeError("GEMINI_API_KEY missing (skipping gemini embedding fallback).")

            if p in {"huggingface", "local"}:
                return _embed_hf_local(text)

            if p == "openai":
                # allow users to explicitly include openai in order
                if cfg.get("OPENAI_API_KEY"):
                    return _embed_openai(text)
                else:
                    raise RuntimeError("OPENAI_API_KEY missing (skipping openai embedding fallback).")

        except Exception as e:
            last_err = e
            log.warning("Embedding fallback '%s' failed. err=%s", p, e)

    raise last_err or RuntimeError("No embedding provider succeeded.")


# ----------------------------
# Main query
# ----------------------------

def query_docs(
    question: str,
    *,
    top_k: Optional[int] = None,
    namespace: Optional[str] = None,
    filter: Optional[Dict[str, Any]] = None,
) -> List[DocChunk]:

    cfg = _cfg()
    try:
        idx = get_pinecone_index()
        vec = embed_with_fallback(question)

        qk = {
            "vector": vec,
            "top_k": top_k or cfg["DEFAULT_TOP_K"],
            "include_metadata": True,
        }
        if namespace:
            qk["namespace"] = namespace
        if filter:
            qk["filter"] = filter

        res = idx.query(**qk)

        chunks: List[DocChunk] = []
        for match in res.matches:
            meta = match.metadata or {}
            chunks.append(
                DocChunk(
                    text=meta.get("text") or meta.get("chunk") or "",
                    score=match.score,
                    source=meta.get("source"),
                    doc_id=meta.get("doc_id") or meta.get("page_id") or meta.get("file_id"),
                    metadata=meta,
                )
            )
        return chunks
    except Exception as e:
        log.warning("Pinecone index query failed (%s). Returning empty chunks.", e)
        return []
