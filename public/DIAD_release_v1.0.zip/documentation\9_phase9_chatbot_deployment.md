# DIAD Phase 9 — Chatbot Deployment & Automation

This phase deploys the Unified Chatbot Engine to Google Cloud Run and schedules daily automated updates for document indexing.

---

## 1. Chatbot APIs

- **Internal Chatbot (`diad-internal-chat`)**:
  - **Endpoint**: `/internal/chat`
  - **Capabilities**: Classifies queries, runs BigQuery SQL queries over marts to get sales/revenue stats, queries internal/external docs in Pinecone, and synthesizes answers.
  - **Security**: Private. Accessible only via internal VPC or through Identity-Aware Proxy (IAP).
- **External Chatbot (`diad-external-chat`)**:
  - **Endpoint**: `/external/chat`
  - **Capabilities**: Resolves order details (order status, items, shipment status) based on order numbers/customer emails, queries external-only docs in Pinecone, and responds with customer-safe details (PII masked).
  - **Security**: Public. Accessible directly over the internet.

---

## 2. Cloud Run Deployment

Deployment builds a single Python container using Google Cloud Build and registers two services targeting different entrypoints.

### 2.1 Deployment Command
Run the deployment script using your deployer service account keys:
```powershell
powershell -ExecutionPolicy Bypass -File scripts/phase9/9_2_deploy_cloud_run.ps1 `
  -ConfigPath config/client_rawdata.json
```

---

## 3. Daily Sync Job & Scheduler

To keep documentation and BigQuery marts fresh, we deploy a Cloud Run Job scheduled daily.

The job is packaged under `scripts/phase9/client_jobs/` and runs:
1. `1_bootstrap_project.ps1`: Enables GCP APIs and sets up service accounts.
2. `2_upsert_secrets.ps1`: Uploads Notion, Confluence, Pinecone, and OpenAI keys to Secret Manager.
3. `3_build_image.ps1`: Builds the job container image (`diad-phase-jobs`).
4. `4_deploy_job.ps1`: Deploys the Cloud Run Job `diad-phase8-sync-docs`.
5. `5_schedule_job.ps1`: Schedules the job to run daily at 02:00 (Asia/Singapore timezone).

### 3.1 Run Job Setup
You can set up and schedule the entire job automation pipeline by executing:
```powershell
powershell -ExecutionPolicy Bypass -File scripts/phase9/client_jobs/9_run_all.ps1
```

---

## 4. Verification & Testing

### 4.1 Smoke Tests
Verify live status using the smoke test script:
```powershell
powershell -ExecutionPolicy Bypass -File scripts/phase9/9_3_smoke_test.ps1
```

### 4.2 Local Running
To run the services locally for sandbox debugging:
```powershell
powershell -ExecutionPolicy Bypass -File scripts/phase9/9_1_run_local.ps1
```
The internal API runs on port 8001 and the external API runs on port 8002.
