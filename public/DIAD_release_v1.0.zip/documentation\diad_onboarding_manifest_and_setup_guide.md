# DIAD Onboarding Manifest & Comparison Guide (v0.5)

This guide documents the setup procedures, resources, and automation mappings for the **Data Intelligence & Analytics Dashboard (DIAD)** platform. It aligns the actual codebase state (Version 0.5) with ChatGPT's recommendations, providing a step-by-step manual setup reference, mapping the automated portal operations, and outlining the cleanup scripts needed to test onboarding from scratch.

---

## 1. Executive Summary & Strategy

Using the **The Diamante Collections** configuration as our "golden test client" is the most robust way to test the onboarding pipeline. We have a fully functional schema, local CSV database seeds, Firestore/GA4 mock schemas, and verified FastAPI chatbot endpoints. 

### Core Truths on the Current Automation State
* **What is Automated**: Secrets configuration in GCP Secret Manager, GCP service enablement, IAM binding validation, Docker image building via Cloud Build, Cloud Run Job deployment (document ingestion), Cloud Scheduler scheduling, and chatbot service deployments (Internal and External APIs).
* **What is Semi-Automated/Developer-Led**: Relational database ingestion (GCS landing and BigQuery raw data loads) and dbt transformations are triggered via CLI runner scripts (`3_1_ingest_ecommerce.py` and `6_1_run_dbt.py`). They are not yet mapped to direct GUI buttons on the client onboarding dashboard, which focuses primarily on GCP credentials, secrets, and Cloud Run API deployments.
* **What is Manual (Customer/Admin Responsibility)**: Creating the initial GCP project and billing link, downloading the service account key, and setting up the GA4/Firestore BigQuery export links.

---

## 2. DIAD Onboarding Manifest

This manifest outlines the prerequisites, resources, and validation gates required for onboarding.

### A. Prerequisites (What the Customer Already Has)
* **GCP Project**: A dedicated Google Cloud Project (e.g., `diamante-diad-test`) with billing active.
* **Google Analytics 4**: An active GA4 property configured to export data to BigQuery.
* **Operational Database**: An active Firestore or e-commerce transaction database.
* **Google Drive Folder**: A folder containing PDFs or text FAQ/policies shared with the service account.
* **Notion Workspace**: A parent page shared with a custom Notion integration.
* **Confluence Space**: A space with an API token.

### B. Resources to Create (The Setup Targets)
* **Service Accounts**:
  * `diad-deployer-sa`: Used for orchestrating local setup.
  * `diad-scheduler-sa`: Used by Cloud Scheduler to trigger ingestion.
* **GCS Buckets**:
  * `gs://[clientname]-diad-storage/` (e.g., `gs://diamante-diad-storage/` for landing scripts and raw inputs).
* **BigQuery Datasets**:
  * `ecommerce_raw`: Staging ground for landed CSVs, GA4 streams, and Firebase logs.
  * `ecommerce_canonical`: Unified tables (e.g., `orders`, `customers`, `products`) with standardized types.
  * `ecommerce_mart`: Materialized aggregate tables (e.g., `customer_360`, `order_dossier`).
* **Secrets Manager Secrets**:
  * `OPENAI_API_KEY`: Vaulted key for GPT-4o-mini chatbot synthesis.
  * `PINECONE_API_KEY`: Vaulted key for vector document lookups.
  * `NOTION_API_KEY`: Vaulted key for Notion RAG crawls.
  * `CONFLUENCE_API_TOKEN`: Vaulted key for Confluence RAG crawls.
  * `GEMINI_API_KEY` (Optional/Fallback): Key for Gemini Flash backup.
* **Vector Index (Pinecone)**:
  * Index: `diad-docs-hf` (384 dimensions, cosine distance) for embedded documents.
* **Compute Resources**:
  * Cloud Run Job: `diad-sync-docs-job` (runs `8_2_sync_docs_to_pinecone.py` daily).
  * Cloud Run Service (Internal): `diad-internal-chat` (restricted access `/internal/chat`).
  * Cloud Run Service (External): `diad-external-chat` (public endpoint `/external/chat`).
  * Cloud Scheduler Trigger: `diad-sync-docs-scheduler`.

### C. Validation & Verification Gates
1. **Preflight Health Check**: Validate local gcloud authentication and BigQuery connection.
2. **dbt Test suite**: Run `dbt test` to ensure relational mappings and data integrity constraints are met.
3. **Pinecone Index Statistics Check**: Verify index size and dimensions via `describe_index_stats()`.
4. **Chatbot API Smoke Tests**: Run HTTP calls to internal and external endpoints.

---

## 3. Step-by-Step Manual Setup Guide

If you need to manually configure the Diamante client or replicate what the code performs under the hood, execute the following steps in order.

### Phase 1: Environment & Secrets Setup
1. **Set Local Environment Variables**:
   ```powershell
   $env:GOOGLE_CLOUD_PROJECT = "diamante-diad-test"
   $env:GOOGLE_APPLICATION_CREDENTIALS = "D:\DataForEntrepreneurs\diad\keys\diamante-diad-key.json"
   ```
2. **Enable Required APIs**:
   ```bash
   gcloud services enable \
     run.googleapis.com \
     cloudbuild.googleapis.com \
     artifactregistry.googleapis.com \
     secretmanager.googleapis.com \
     cloudscheduler.googleapis.com \
     iam.googleapis.com \
     iamcredentials.googleapis.com
   ```
3. **Provision GCP Secret Manager Keys**:
   ```bash
   # Create secrets
   for s in OPENAI_API_KEY PINECONE_API_KEY NOTION_API_KEY CONFLUENCE_API_TOKEN GEMINI_API_KEY; do
     gcloud secrets create "$s" --replication-policy="automatic"
   done

   # Upload versions
   printf "%s" "sk-YOUR-OPENAI-KEY"    | gcloud secrets versions add OPENAI_API_KEY --data-file=-
   printf "%s" "pcsk-YOUR-PINECONE-KEY" | gcloud secrets versions add PINECONE_API_KEY --data-file=-
   printf "%s" "secret_YOUR-NOTION-KEY" | gcloud secrets versions add NOTION_API_KEY --data-file=-
   ```

### Phase 2: Ingest Raw Structured Data
1. **Generate Seed Files & Land to GCS**:
   Generates mock transactional records (customers, products, orders) and uploads them to your GCS storage bucket:
   ```powershell
   python scripts/3_1_ingest_ecommerce.py
   ```
   *Internal commands executed*:
   * `scripts/phase3/generate_seed.py`
   * `scripts/phase3/create_datasets_and_tables.py`
   * `scripts/phase3/upload_to_gcs.py`
   * `scripts/phase3/load_raw_and_transform.py`

2. **Load Firebase/Firestore Ingestion (Optional)**:
   If Firestore data is active:
   ```powershell
   python scripts/2_1_firestore_to_bq.py
   python scripts/2_2_firebase_auth_users_to_bq.py
   python scripts/2_3_build_consolidated.py
   ```

### Phase 3: Run dbt Modeling
Builds the analytical warehouse views and tables inside BigQuery:
```powershell
# Activate dbt virtual env
.\venv_dbt\Scripts\activate

# Run dbt build (seeds, staging, canonical, mart, test)
python scripts/6_1_run_dbt.py --mode full
```

### Phase 4: Build Chatbot Dossiers & Customer 360 Tables
Prepares specific BigQuery tables optimized for chatbot querying:
```powershell
python scripts/7_run_all.py
```

### Phase 5: Embed Documents to Pinecone
1. **Create Pinecone Index**:
   ```powershell
   python scripts/phase8/8_1_create_pinecone_index.py
   ```
2. **Crawl & Sync Documents**:
   Crawls Google Drive folders, Notion parent pages, and Confluence spaces. Embeds them locally via HuggingFace `MiniLM-L6-v2` and uploads the vectors:
   ```powershell
   python scripts/phase8/8_2_sync_docs_to_pinecone.py
   ```

### Phase 6: Build & Deploy Containerized Services
1. **Deploy Background Sync Job**:
   Builds the synchronization container and schedules it daily:
   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts/phase9/client_jobs/3_build_image.ps1
   powershell -ExecutionPolicy Bypass -File scripts/phase9/client_jobs/4_deploy_job.ps1
   powershell -ExecutionPolicy Bypass -File scripts/phase9/client_jobs/5_schedule_job.ps1
   ```
2. **Deploy Chatbot APIs**:
   Deploys `diad-internal-chat` and `diad-external-chat` to Google Cloud Run:
   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts/phase9/9_2_deploy_cloud_run.ps1 -ConfigPath config/client_rawdata.json
   ```

---

## 4. How the Automated Portal Maps to Manual Setup

The **DIAD Onboarding Portal** (`scripts/onboarding_dashboard.py`) runs as a local daemon at `http://localhost:8000`. It exposes an interactive interface mapping directly to the manual steps:

| Dashboard Element | Action / Tab Name | Backend Command Executed / Logic |
| :--- | :--- | :--- |
| **GCP Setup** | Tab 1: GCP Account Setup | Client uploads service account key JSON; daemon parses `project_id` and saves it to `keys/client-service-account.json`. |
| **Link Sources** | Tab 2: Link Guide | Directs user through manual steps for sharing Drive folders, creating Notion integration, and linking GA4/Firebase to BigQuery. |
| **API Keys** | Tab 3: GCP Secrets Vault | Saves OpenAI, Pinecone, Notion, and Confluence tokens directly into GCP Secret Manager using impersonated `gcloud secrets` commands. |
| **Step 1** | Run Preflight Check | Runs `python scripts/phase9/9_0_preflight.py --config config/client_rawdata.json`. Verifies BigQuery access and Pinecone index availability. |
| **Step 2** | Bootstrap GCP Project | Runs `scripts/phase9/client_jobs/1_bootstrap_project.ps1`. Enables GCP APIs, creates Artifact Registry, creates Scheduler Service Account, and assigns Secret Accessor roles. |
| **Step 3** | Upsert Secrets | Renders vault form link (completed in Tab 3). |
| **Step 4** | Build Jobs Docker Image | Runs `scripts/phase9/client_jobs/3_build_image.ps1`. Sends source directory to Cloud Build to package the Docker image and push to Artifact Registry. |
| **Step 5** | Deploy Sync Cloud Run Job | Runs `scripts/phase9/client_jobs/4_deploy_job.ps1`. Configures and deploys Cloud Run Job executing `8_2_sync_docs_to_pinecone.py`. |
| **Step 6** | Deploy Chatbot Services | Runs `scripts/phase9/9_2_deploy_cloud_run.ps1`. Deploys the internal and external chatbot APIs from the same container image. |
| **Step 7** | Schedule Daily Sync | Runs `scripts/phase9/client_jobs/5_schedule_job.ps1`. Sets up a Cloud Scheduler trigger pointed at the sync job URL. |
| **Step 8** | Run Smoke Tests | Runs `scripts/phase9/9_3_smoke_test.ps1`. Triggers HTTP requests and logs service availability checks. |

---

## 5. Detailed Resource Inventory: Codebase vs. ChatGPT

ChatGPT identified several layers of resources. Here is the actual state of those resources in the codebase:

| Category | ChatGPT Resource | Codebase Implementation / Reality |
| :--- | :--- | :--- |
| **GCP** | Project & Enabled APIs | Manually created; APIs enabled via `1_2_enable_apis.py` or Step 2. |
| **GCP** | Service accounts | `diad-deployer-sa` (manual), `diad-scheduler-sa` (automated in Step 2). |
| **GCP** | Cloud Run services | `diad-internal-chat` and `diad-external-chat` (automated in Step 6). |
| **GCP** | Secrets | `OPENAI_API_KEY`, `PINECONE_API_KEY`, `NOTION_API_KEY`, `CONFLUENCE_API_TOKEN` (vaulted via Tab 3). |
| **GCP** | Buckets | GCS bucket specified in `client.export.bucket` (e.g., `gs://diamante-diad-storage/`). |
| **BigQuery** | Datasets | `ecommerce_raw`, `ecommerce_canonical`, `ecommerce_mart` (automated in Phase 3/6A). |
| **BigQuery** | Tables & Views | Raw tables: `customers`, `products`, `orders`. Mart tables: `order_dossier`, `customer_360` (created via dbt/Phase 7). |
| **dbt** | Models & profiles | Inside `dbt/diad_dbt/` (staging, canonical, mart models) and `dbt/profiles/profiles.yml`. |
| **Shopify** | App credentials | Simulated in version 0.5 via mock CSV transactional data seeds. |
| **GA4** | BigQuery Export | Configured inside GA4 console; maps directly to BigQuery raw datasets. |
| **AI** | Pinecone Index | `diad-docs-hf` (crawled pages) and optional `diad-order-dossiers-hf` (snapshot mode). |
| **AI** | Embedded metadata | Ingested via local HuggingFace `MiniLM-L6-v2` embedder inside the sync job. |
| **Dashboard**| Local Server UI | Running via FastAPI `onboarding_dashboard.py` (serves the diagnostic page and guide bot). |

---

## 6. Clean Teardown and Reset Guide

To test the onboarding automation from a completely clean state (validating that the setup succeeds from scratch), run these cleanup commands.

> [!WARNING]
> This will destroy your test datasets, Cloud Run deployments, and secrets. Make sure your active `gcloud` configuration points to your test project (`diamante-diad-test` / `diamante-diad3`) and **not** a production customer's project.

### 1. Delete Cloud Run Services & Scheduler Jobs
```powershell
# Stop and delete scheduler triggers
gcloud scheduler jobs delete diad-sync-docs-scheduler --quiet

# Delete Cloud Run Jobs
gcloud run jobs delete diad-sync-docs-job --quiet

# Delete Chatbot Web Services
gcloud run services delete diad-internal-chat --quiet
gcloud run services delete diad-external-chat --quiet
```

### 2. Delete Secret Manager Secrets
```powershell
# Delete the vaulted client credentials
for ($s in "OPENAI_API_KEY", "PINECONE_API_KEY", "NOTION_API_KEY", "CONFLUENCE_API_TOKEN", "GEMINI_API_KEY") {
  gcloud secrets delete $s --quiet
}
```

### 3. Delete BigQuery Datasets
This deletes the raw logs, canonical tables, and marts (views and tables generated by dbt/Phase 7):
```powershell
# Force delete datasets including all tables and views
bq rm -r -f -d ecommerce_raw
bq rm -r -f -d ecommerce_canonical
bq rm -r -f -d ecommerce_mart
```

### 4. Clear GCS Storage Landing
```powershell
# Clear all files in the client storage bucket
gcloud storage rm gs://diamante-diad-storage/**
```

### 5. Clear Pinecone Index Vectors
You can either delete the namespace or clear the entire index:
```python
# Save this script as scratch/clear_pinecone.py and execute it
import os
from pinecone import Pinecone

api_key = os.getenv("PINECONE_API_KEY", "YOUR-TEST-KEY")
pc = Pinecone(api_key=api_key)
idx = pc.Index("diad-docs-hf")

# Option A: Delete entire index
# pc.delete_index("diad-docs-hf")

# Option B: Delete all vectors in a specific namespace
idx.delete(delete_all=True, namespace="diamante-docs")
```

### 6. Reset Local Onboarding State
To force the onboarding dashboard (`onboarding_dashboard.py`) back to Step 1 (Stage 1):
1. Delete the `keys/client-service-account.json` file.
2. Edit `config/client_rawdata.json` and change `client.project_id` to `"Not Configured"` or `"diamante-diad"`.
3. Restart `python scripts/onboarding_dashboard.py`.
