# {{BUSINESS_NAME}} — AI Chatbot Website Integration & Hand-Off Guide

Welcome! This integration package contains everything required to deploy the **DIAD AI Chatbot Suite** for **{{BUSINESS_NAME}}**. 

---

## 📦 What's Included in This Package

| File | Description | Target Location |
| :--- | :--- | :--- |
| `diad-chat-widget.js` | 💬 Floating support widget (bottom-right chat bubble) | Public website folder / Assets |
| `external_chatbot.html` | 🛍️ Full-page customer support portal (`/external_chatbot`) | Public website root |
| `internal_chatbot.html` | 📊 Internal Executive BI & text-to-SQL advisor (`/internal_chatbot`) | Team intranet / Restricted path |
| `_redirects` | ⚡ Netlify & SPA URL routing configuration | Site root folder |
| `README_FOR_CLIENT.md` | 📖 Comprehensive step-by-step integration guide | Team documentation |

---

## 🚀 1. Add Floating Chat Bubble Widget (1-Line Storefront Embed)

To add the interactive 💬 floating chat widget to all pages of your e-commerce storefront:

### Step A: Place `diad-chat-widget.js` on your website server
Copy `diad-chat-widget.js` into your website's public static asset folder (e.g., `public/`, `assets/`, or root directory).

### Step B: Insert the 1-Line Script Tag
Paste this single line of HTML immediately before the closing `</body>` tag in your site layout template:

```html
<script src="/diad-chat-widget.js" defer></script>
```

---

## 💻 Platform-Specific Integration Guides

### 🛍️ Option A: Shopify Integration
1. Log into your **Shopify Admin Dashboard**.
2. Go to **Online Store** → **Themes**.
3. Click the `...` (Actions) button next to your active theme and select **Edit Code**.
4. In the left file tree, open `Layout` → `theme.liquid`.
5. Scroll to the bottom of `theme.liquid`, paste `<script src="/diad-chat-widget.js" defer></script>` directly above `</body>`, and click **Save**.
6. *(Optional)* Upload `diad-chat-widget.js` under **Assets** → **Add a new asset**.

### 💙 Option B: WooCommerce / WordPress Integration
1. Log into your **WordPress Admin Dashboard**.
2. Go to **Plugins** → **Add New**, search for **WPCode** (Insert Headers and Footers), and click **Install & Activate**.
3. Go to **Code Snippets** → **Header & Footer**.
4. In the **Footer** section, paste:
   ```html
   <script src="/diad-chat-widget.js" defer></script>
   ```
5. Click **Save Changes**.

### 🌐 Option C: Wix / Squarespace / Webflow Integration
1. **Wix**: Go to **Settings** → **Custom Code** → click **+ Add Custom Code**. Paste the script tag under **Body - End** and apply to **All Pages**.
2. **Squarespace**: Go to **Settings** → **Developer Tools** → **Code Injection**. Paste the script tag into the **Footer** section.
3. **Webflow**: Go to **Project Settings** → **Custom Code** → paste into **Footer Code**.

### ⚡ Option D: Netlify / Custom HTML / React / Vue Integration
1. Copy `diad-chat-widget.js`, `external_chatbot.html`, and `internal_chatbot.html` into your site's `public/` or root directory.
2. Copy `_redirects` to your root directory for seamless clean URLs (`/external_chatbot` and `/internal_chatbot`).
3. Commit to GitHub / deploy to Netlify.

---

## 🔒 Security & Backend API Architecture

- **Customer Support Endpoint**: `{{EXTERNAL_API_URL}}`
- **Internal BI Endpoint**: `{{INTERNAL_API_URL}}`
- **GCP Project ID**: `{{PROJECT_ID}}`
- **PII Data Security**: Customer emails, phone numbers, and street addresses are automatically masked in real-time before reaching vector stores or response generators.

---

## ❓ Frequently Asked Questions & Troubleshooting

- **Q: Chat bubble isn't showing up on my store?**
  - Verify that `diad-chat-widget.js` is accessible at `https://yourwebsite.com/diad-chat-widget.js` in your browser.
  - Make sure the script tag has `defer` attribute set and is placed before `</body>`.
- **Q: Can I customize colors or branding?**
  - Yes! Open `diad-chat-widget.js` and edit the primary color variables at the top of the file (`#7f5af0`, `#00f2fe`).

---

*Powered by **DIAD Engine** — Data Integration & AI Deployment for Entrepreneurs*
