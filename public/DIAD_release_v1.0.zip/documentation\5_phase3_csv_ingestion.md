# DIAD Phase 3 — Backend CSV Ingestion & Schema Alignment

This phase processes CSV and external data feeds, uploading them to GCS and importing them into schema-aligned BigQuery tables in the `ecommerce_raw` dataset.

---

## 1. Phase 3 Ingestion Pipeline

The pipeline is managed by scripts under `scripts/phase3/`:

1. **`generate_seed.py`**:
   - Generates mock customer, product, and order datasets for testing/sandbox runs.
2. **`create_datasets_and_tables.py`**:
   - Programmatically defines tables for raw data landing in BigQuery.
3. **`upload_to_gcs.py`**:
   - Uploads CSV files from local folders to the GCS landing path: `gs://<bucket>/landing/phase3/`.
4. **`load_raw_and_transform.py`**:
   - Invokes BigQuery load jobs to parse CSV schema data and load them into BigQuery raw tables.

---

## 2. Ingestion Orchestrator

The main runner script is `scripts/phase3/run_all.py`, which coordinates the steps (generating data, uploading to GCS, and transforming/loading to BigQuery) sequentially.

---

## 3. Run Commands

To trigger Phase 3 pipeline ingestion manually:
```powershell
# Run the entire pipeline orchestrator
python scripts/phase3/run_all.py --config config/client_rawdata.json

# Or run individual steps
python scripts/phase3/generate_seed.py --config config/client_rawdata.json
python scripts/phase3/create_datasets_and_tables.py --config config/client_rawdata.json
python scripts/phase3/upload_to_gcs.py --config config/client_rawdata.json
python scripts/phase3/load_raw_and_transform.py --config config/client_rawdata.json
```

---

## 4. Verification

After execution, verify the row counts of raw datasets using standard SQL in BigQuery:
```sql
SELECT count(*) FROM `diamante-diad3.ecommerce_raw.customers`;
SELECT count(*) FROM `diamante-diad3.ecommerce_raw.orders`;
```
Ensure they match the values specified in `ingest.seed_record_counts` in the config JSON.
