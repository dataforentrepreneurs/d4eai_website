# chatbot/internal_api.py
"""
Internal chatbot API (employee-facing) – direct BigQuery mode.

uvicorn chatbot.internal_api:app --reload --port 8001     

http://127.0.0.1:8001/docs

Exposes:
  GET  /             -> health check
  POST /internal/chat

Flow:
  1. Receive user question.
  2. Classify into high-level intent.
  3. Build SQL template over marts.
  4. Execute BigQuery.
  5. For some intents, summarize results via LLMClient
     (OpenAI primary, Gemini fallback).

gcloud run services update diad-internal-chat `
  --project=diamante-diad `
  --region=asia-southeast1 `
  --set-env-vars OPENAI_API_KEY="<YOUR_OPENAI_API_KEY>"

gcloud run deploy diad-internal-chat `
  --project=diamante-diad3 `
  --region=asia-southeast1 `
  --source . `
  --no-allow-unauthenticated `
  --command "uvicorn" `
  --args "chatbot.internal_api:app","--host","0.0.0.0","--port","8080"

    
gcloud run services logs read diad-internal-chat `
  --project=diamante-diad3 `
  --region=asia-southeast1 `
  --limit=200

gcloud run services describe diad-internal-chat `
  --project=diamante-diad `
  --region=asia-southeast1 `
  --format="value(spec.template.spec.serviceAccountName)"

gcloud projects add-iam-policy-binding diamante-diad `
  --member="serviceAccount:38640153199-compute@developer.gserviceaccount.com" `
  --role="roles/bigquery.jobUser"

gcloud projects add-iam-policy-binding diamante-diad `
  --member="serviceAccount:38640153199-compute@developer.gserviceaccount.com" `
  --role="roles/bigquery.dataViewer"

gcloud projects add-iam-policy-binding diamante-diad `
  --member="serviceAccount:38640153199-compute@developer.gserviceaccount.com" `
  --role="roles/secretmanager.secretAccessor"  

$URL = "https://diad-internal-chat-38640153199.asia-southeast1.run.app/internal/chat"
$TOKEN = gcloud auth print-identity-token
@"
{"question":"How does the external chatbot work?"}
"@ | Set-Content -Encoding utf8 .\req.json

curl.exe -X POST $URL `
  -H "Authorization: Bearer $TOKEN" `
  -H "Content-Type: application/json" `
  --data-binary "@req.json"

Sample questions:
what is the return policy?
how many documents you have access to?
What are business OKRs?
can I have data dictionary for the company?
what are the Packaging Guidelines?

gcloud run services add-iam-policy-binding diad-internal-chat `
  --region asia-southeast1 `
  --project diamante-diad3 `
  --member="user:YOUR_EMAIL" `
  --role="roles/run.invoker"

  
  
$URL = "https://diad-internal-chat-66176258702.asia-southeast1.run.app"
$TOKEN = gcloud auth print-identity-token

Invoke-RestMethod -Method Post `
  -Uri "$URL/internal/chat" `
  -Headers @{ Authorization = "Bearer $TOKEN" } `
  -ContentType "application/json" `
  -Body '{"question":"what is the return policy?","history":[]}'

  """

from typing import Any, Dict, List, Optional
from decimal import Decimal
from datetime import datetime, date
import json
import logging
import re

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from .bq_utils import build_bq_client, load_raw_config, get_client_cfg
from .llm_client import LLMClient

from enum import Enum

from .rag_docs import query_docs, DocChunk  

import sys
from contextlib import asynccontextmanager


from dotenv import load_dotenv
load_dotenv(".env.local")

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


raw_cfg: Optional[dict] = None
client_cfg: Optional[dict] = None
bq_client = None
llm: Optional[LLMClient] = None

PROJECT_ID: Optional[str] = None
MART_DATASET: Optional[str] = None

def _require_ready() -> None:
    if not (raw_cfg and client_cfg and bq_client and llm and PROJECT_ID and MART_DATASET):
        raise RuntimeError("Service not initialized yet (lifespan has not completed).")

@asynccontextmanager
async def lifespan(app: FastAPI):
    global raw_cfg, client_cfg, bq_client, llm, PROJECT_ID, MART_DATASET
    raw_cfg = load_raw_config()
    client_cfg = get_client_cfg(raw_cfg)
    PROJECT_ID = client_cfg.get("project_id")
    MART_DATASET = (client_cfg.get("warehouse", {}) or {}).get("marts_dataset") or "ecommerce_mart"
    bq_client = build_bq_client(raw_cfg)
    llm = LLMClient(raw_cfg)
    yield

app = FastAPI(title="DIAD Internal Chatbot API", version="0.4.0", lifespan=lifespan)

# ---------- Health endpoint ----------


@app.get("/health")
def health():
    return {"status": "ok", "service": "DIAD internal chatbot"}

@app.get("/")
def root():
    return {"status": "ok", "service": "DIAD internal chatbot"}


# ---------- Models ----------
class QuestionType(str, Enum):
    DATA_ONLY = "data_only"
    DOCS_ONLY = "docs_only"
    HYBRID = "hybrid"


class ChatRequest(BaseModel):
    question: str
    history: Optional[List[Dict[str, str]]] = None


class ChatResponse(BaseModel):
    answer: str
    sql: Optional[str] = None
    rows_preview: Optional[List[Dict[str, Any]]] = None
    intent: Optional[str] = None
    

# ---------- Helpers ----------


def make_jsonable(obj: Any) -> Any:
    """Convert BigQuery row values (Decimal, datetime, etc.) into JSON-safe types."""
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, list):
        return [make_jsonable(x) for x in obj]
    if isinstance(obj, dict):
        return {k: make_jsonable(v) for k, v in obj.items()}
    return obj

def classify_question_type(question: str) -> QuestionType:
    """
    Rough classifier for whether the question needs:
      - warehouse data
      - docs
      - or both (hybrid)

    You can refine later or replace with an LLM classifier.
    """
    q = question.lower()

    data_keywords = [
        "orders", "order", "revenue", "conversion", "sessions", "visits",
        "customers", "top customers", "churn", "active users", "last days",
        "trend", "growth", "kpis", "metrics",
    ]
    docs_keywords = [
        "how does", "architecture", "pipeline", "process",
        "okrs", "okr", "roadmap", "design", "explain",
        "definition", "what is", "how we", "documentation",
    ]

    has_data = any(k in q for k in data_keywords)
    has_docs = any(k in q for k in docs_keywords)

    if has_data and has_docs:
        return QuestionType.HYBRID
    if has_data:
        return QuestionType.DATA_ONLY
    if has_docs:
        return QuestionType.DOCS_ONLY

    # default: hybrid for internal users – “be helpful”
    return QuestionType.HYBRID


def classify_intent(question: str) -> str:
    """
    Very lightweight intent detection.
    """
    q = question.lower()

    if "order" in q and "last" in q and "day" in q:
        return "orders_last_days"

    if "top customers" in q or "top customer" in q:
        return "top_customers_30_days"

    if "order history" in q or "customer history" in q:
        return "customer_order_history"

    return "fallback_unknown"


def _extract_days_from_question(question: str, default: int = 7) -> int:
    """
    Parse 'last N days' from question. If no number found, returns default.
    """
    q = question.lower()
    m = re.search(r"last\s+(\d+)\s+day", q)
    if m:
        try:
            return int(m.group(1))
        except ValueError:
            pass
    return default


def build_orders_last_days_sql(days: int) -> str:
    """
    Build SQL for 'orders_last_days' intent.

    Returns per-day counts plus a window SUM over the entire N-day period so
    we can answer "total orders in last N days" without extra queries.
    """
    order_dossier_tbl = f"`{PROJECT_ID}.{MART_DATASET}.order_dossier_tbl`"
    return f"""
    WITH daily AS (
      SELECT
        DATE(order_datetime) AS order_date,
        COUNT(*) AS order_count
      FROM {order_dossier_tbl}
      WHERE order_datetime >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL {days} DAY)
      GROUP BY order_date
    )
    SELECT
      order_date,
      order_count,
      SUM(order_count) OVER () AS total_orders_last_{days}_days
    FROM daily
    ORDER BY order_date DESC
    LIMIT 30
    """


def build_sql_for_intent(intent: str, question: str) -> Optional[str]:
    """
    SQL templates for non-orders_last_days intents.
    """
    order_dossier_tbl = f"`{PROJECT_ID}.{MART_DATASET}.order_dossier_tbl`"
    customer_tbl = f"`{PROJECT_ID}.{MART_DATASET}.customer_360_tbl`"

    if intent == "top_customers_30_days":
        return f"""
        SELECT
          c.customer_id_bk,
          c.full_name,
          c.email,
          COUNT(*) AS order_count_30d
        FROM {order_dossier_tbl} AS o
        JOIN {customer_tbl} AS c
          ON o.customer_sk = c.customer_sk
        WHERE o.order_datetime >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 30 DAY)
        GROUP BY c.customer_id_bk, c.full_name, c.email
        ORDER BY order_count_30d DESC
        LIMIT 20
        """

    if intent == "customer_order_history":
        return f"""
        SELECT
          order_number,
          order_datetime,
          customer_sk,
          ARRAY_LENGTH(items) AS item_count
        FROM {order_dossier_tbl}
        ORDER BY order_datetime DESC
        LIMIT 50
        """

    return None


def summarize_with_llm(
    question: str,
    rows: List[Dict[str, Any]],
    intent: str,
    sql: str,
    ) -> str:
    """
    Use LLMClient to generate a concise internal-analytics answer.
    """
    if not rows:
        return "I ran a query but did not find any matching rows."

    preview = rows[:10]

    system_prompt = (
        "You are an internal analytics assistant for The Diamante Collections. "
        "You answer questions about orders and customers based strictly on the SQL results provided. "
        "Be concise and business-friendly. If there is any uncertainty, say so."
    )

    user_content = (
        f"Business question:\n{question}\n\n"
        f"Detected intent: {intent}\n\n"
        f"SQL used:\n{sql}\n\n"
        f"First rows of the result (JSON):\n"
        f"{json.dumps(preview, ensure_ascii=False)[:4000]}"
    )

    try:
        answer = llm.chat(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content},
            ],
            temperature=0.2,
        )
        return answer.strip() if answer else "I could not generate a summary from the results."
    except Exception as e:
        logger.exception("Error while summarizing with LLM: %s", e)
        return "I retrieved some data, but there was an error summarizing it."

def build_multi_source_answer(
    question: str,
    history: Optional[List[Dict[str, str]]],
    question_type: QuestionType,
    intent: str,
    sql: Optional[str],
    rows: List[Dict[str, Any]],
    doc_chunks: List[DocChunk],
) -> str:
    """
    Single place to call LLMClient with both:
      - BigQuery summary
      - Docs context
    """

    # --- BigQuery summary (if any) ---
    if rows and sql:
        preview_rows = rows[:10]
        bq_summary = (
            f"SQL used:\n{sql}\n\n"
            f"First rows of the result (JSON):\n"
            f"{json.dumps(preview_rows, ensure_ascii=False)[:4000]}"
        )
    elif sql:
        bq_summary = f"SQL used:\n{sql}\n\nNo rows returned."
    else:
        bq_summary = "No structured data (BigQuery) included for this question."

    # --- Docs context (if any) ---
    doc_lines = []
    for i, chunk in enumerate(doc_chunks, start=1):
        source = chunk.source or "unknown"
        doc_id = chunk.doc_id or ""
        doc_lines.append(
            f"[DOC {i} | source={source} | id={doc_id} | score={chunk.score:.3f}]\n"
            f"{chunk.text}\n"
        )
    doc_context = "\n\n".join(doc_lines) if doc_lines else "No documentation snippets retrieved."

    biz_name = client_cfg.get("business_name", "our store")
    system_prompt = (
        f"You are an internal analytics and documentation assistant for {biz_name}.\n"
        "You can use both:\n"
        "1) Structured data from the warehouse (BigQuery) – e.g., metrics, order counts, top customers.\n"
        "2) Unstructured docs – architecture, OKRs, roadmaps, process docs from Notion / Confluence / Drive.\n\n"
        "Rules:\n"
        "- Base your answer on the context provided where possible.\n"
        "- If specific company documentation or structured data is missing or not provided in the context, do NOT refuse to answer. Instead, leverage your general knowledge to provide a highly professional, generic, and industry-standard best practice response tailored to the question (e.g., standard ecommerce packing policies, typical business goals or mission frameworks, standard operational procedures) as the assistant for the company. Do NOT output any meta-announcements, notes, or disclaimers stating that the search context or specific files were not found.\n"
        "- For hybrid questions, clearly separate numeric insight from documentation context.\n"
        "- Be concise, business-friendly, and avoid SQL jargon unless explicitly asked.\n"
    )

    user_content = (
        f"Conversation history:\n{json.dumps(history or [])}\n\n"
        f"User question:\n{question}\n\n"
        f"Question type: {question_type.value}\n"
        f"Detected data intent (if any): {intent}\n\n"
        f"[STRUCTURED DATA CONTEXT]\n{bq_summary}\n\n"
        f"[DOC CONTEXT]\n{doc_context}\n\n"
        "Using ONLY the above, answer the question. If important information is missing, "
        "explain what is missing instead of guessing."
    )

    # IMPORTANT: use LLMClient so you keep OpenAI → Gemini fallback. :contentReference[oaicite:6]{index=6}
    answer = llm.chat(
        [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
        temperature=0.2,
    )
    return answer.strip()


# ---------- Endpoint ----------

@app.post("/internal/chat", response_model=ChatResponse)
def internal_chat(req: ChatRequest) -> ChatResponse:
    _require_ready()

    question = req.question

    # New: classify source type (data/docs/hybrid)
    question_type = classify_question_type(question)

    # Existing: data-side intent (for SQL)
    intent = classify_intent(question)

    sql: Optional[str] = None
    rows: List[Dict[str, Any]] = []

    # ---------- BigQuery branch (only if needed) ----------
    if question_type in (QuestionType.DATA_ONLY, QuestionType.HYBRID):
        if intent == "orders_last_days":
            days = _extract_days_from_question(question, default=7)
            sql = build_orders_last_days_sql(days)
        else:
            sql = build_sql_for_intent(intent, question)

        if not sql:
            # No known SQL for this question → we still may answer from docs below.
            logging.info("No SQL mapped for intent=%s; question_type=%s", intent, question_type)
        else:
            logger.info(
                "internal_chat | question_type=%s intent=%s has_sql=%s rows=%d",
                question_type.value,
                intent,
                bool(sql),
                len(rows),
            )

            try:
                job = bq_client.query(sql)
                raw_rows = [dict(r) for r in job.result()]
                rows = [make_jsonable(r) for r in raw_rows]
            except Exception as e:
                logger.exception("Error running BigQuery query: %s", e)
                raise HTTPException(
                    status_code=500,
                    detail="Error while querying the warehouse. Check server logs.",
                )

    # ---------- Docs branch (only if needed) ----------
    doc_chunks: List[DocChunk] = []
    if question_type in (QuestionType.DOCS_ONLY, QuestionType.HYBRID):
        try:
            # For now, no namespace/filter → all internal docs.
            # Later: use namespace='internal' or filter={"visibility": "internal"}
            #doc_chunks = query_docs(question)
            #doc_chunks = query_docs(question, top_k=5)

            for ns in ["gdrive", "notion", "confluence"]:
                doc_chunks.extend(query_docs(question, top_k=5, namespace=ns))

            # sort best-first and keep top 5 overall
            doc_chunks.sort(key=lambda c: c.score, reverse=True)
            doc_chunks = doc_chunks[:5]

            # docs_internal = query_docs(question, top_k=3, namespace="internal")
            # docs_external = query_docs(question, top_k=2, namespace="external")
            # doc_chunks = docs_internal + docs_external

        except Exception as e:
            logger.exception("Error querying docs index: %s", e)
            # We don't fail the request; we just proceed without docs.
            doc_chunks = []

    # ---------- Build answer ----------
    # Special case: pure `orders_last_days` with no docs requested → keep old deterministic style.
    if (
        question_type == QuestionType.DATA_ONLY
        and intent == "orders_last_days"
        and doc_chunks == []
    ):
        days = _extract_days_from_question(question, default=7)
        col_name = f"total_orders_last_{days}_days"

        if not rows:
            answer = f"In the last {days} days, there were 0 orders."
        else:
            total_val = rows[0].get(col_name)
            try:
                total = int(total_val) if total_val is not None else 0
            except (TypeError, ValueError):
                total = 0

            shown = len(rows)
            answer = (
                f"In the last {days} days, there were {total} orders. "
                f"Here are the most recent {shown} day(s) of activity."
            )
    else:
        # For all other cases, use the multi-source builder.
        answer = build_multi_source_answer(
            question=question,
            history=req.history,
            question_type=question_type,
            intent=intent,
            sql=sql,
            rows=rows,
            doc_chunks=doc_chunks,
        )

    preview = rows[:10] if rows else None

    return ChatResponse(
        answer=answer,
        sql=sql,
        rows_preview=preview,
        intent=intent,
    )

# ---------- End of file ----------