import json
from pathlib import Path

def load_client_config():
    # utils/config_loader.py → repo root is parent of utils/
    repo_root = Path(__file__).resolve().parents[1]   # diad/
    cfg_path = repo_root / "config" / "client_rawdata.json"
    with open(cfg_path, "r", encoding="utf-8") as f:
        return json.load(f)
