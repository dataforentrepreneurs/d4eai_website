# DIAD Platform Architecture & System Structure

This document provides a high-level overview of the **Data in a Day (DIAD)** platform, detailing why it is structured this way, how the components interact, and mapping out the codebase folder structure.

---

## 1. System Design Philosophy

DIAD is designed to automate the deployment of a modern data warehouse and AI chatbot system for small businesses in a single day. The design follows three core principles:
1. **Separation of Concerns**: Unstructured documentation (Notion/Drive) and structured transactional data (BigQuery) flow through separate pipelines, merging only at the final LLM reasoning layer.
2. **Cost Efficiency**: Using open-source local embeddings (HuggingFace `MiniLM` running inside the sync job) avoids costly OpenAI embedding API fees, while keeping RAG latency sub-second.
3. **SaaS tenant Isolation**: Each client’s deployment is fully isolated through configuration files (`config/client_rawdata.json`) and project service accounts.

---

## 2. Overall Data Flow

```mermaid
graph TD
    %% Telemetry & Docs Ingestion
    subgraph "1. Client Data Sources"
        GA4[Google Analytics]
        Firestore[Firestore Collections]
        Firebase[Firebase Auth Users]
        CSV[Transactional CSVs]
        Docs[Drive / Notion / Confluence]
    end

    %% Ingestion Landing
    subgraph "2. Raw Storage (GCS & BQ)"
        Bucket[gs://client-diad-bucket/]
        BQ_Raw[BigQuery raw datasets]
    end

    %% Modeling Warehouse
    subgraph "3. Modeling & Aggregation (dbt)"
        DBT_stg[Staging Views]
        DBT_can[Canonical Tables]
        DBT_marts[customer_360 / order_dossier]
    end

    %% Pinecone Sync
    subgraph "4. Vector Database (Pinecone)"
        HF[HuggingFace Embedder]
        Index[(Pinecone Index)]
    end

    %% Cloud Run Service
    subgraph "5. Answer Engine (FastAPI)"
        Run[FastAPI on Cloud Run]
        LLM[LLM: OpenAI / Gemini Fallback]
    end

    %% Ingestion Links
    GA4 -->|Auto Export| BQ_Raw
    Firestore -->|2_1_firestore_to_bq.py| Bucket
    Firebase -->|2_2_firebase_auth_users_to_bq.py| Bucket
    CSV -->|3_1_ingest_ecommerce.py| Bucket
    Bucket -->|Load Jobs| BQ_Raw

    %% Modeling links
    BQ_Raw -->|6_1_run_dbt.py| DBT_stg
    DBT_stg --> DBT_can
    DBT_can -->|7_run_all.py| DBT_marts

    %% RAG links
    Docs -->|8_2_sync_docs_to_pinecone.py| HF
    HF -->|384-dim Vectors| Index

    %% Chatbot Links
    DBT_marts -->|Direct SQL Query| Run
    Index -->|Vector Search & Filters| Run
    Run -->|Synthesize context| LLM
    LLM -->|Live Responses| Widget[Website Widget]
```

---

## 3. Codebase Directory Structure

Here is how the repository folders correspond to the phases:

```
DIAD/
│
├── config/
│   └── client_rawdata.json     # Client settings, bucket names, and source IDs (Phase 1)
│
├── keys/
│   ├── diamante-diad-*.json    # Service account key for GCP target project (Phase 0)
│   └── diad-*.json             # Service account key for DIAD Admin project (Phase 0)
│
├── chatbot/                    # FastAPI chatbot endpoints & LLM logic (Phase 9)
│   ├── bq_utils.py             # BigQuery connection handlers
│   ├── llm_client.py           # OpenAI client with Gemini fallback logic
│   ├── rag_docs.py             # Pinecone querying with visibility filters
│   ├── internal_api.py         # Private endpoint (/internal/chat)
│   └── external_api.py         # Public endpoint (/external/chat)
│
├── dbt/
│   └── diad_dbt/               # SQL transformation models (Phase 6A)
│       ├── models/
│       │   ├── staging/        # Clean raw source fields
│       │   ├── canonical/      # Standard object schemas (orders, customers)
│       │   └── marts/          # Aggregate views (customer_360, order_dossier)
│       └── dbt_project.yml
│
└── scripts/
    ├── phase3/                 # Ingest backend CSV files to BigQuery (Phase 3)
    ├── phase7/                 # Materialize custom marts tables (Phase 7)
    ├── phase8/                 # Crawl docs & upsert to Pinecone (Phase 8)
    ├── phase9/                 # Deploy chatbot services & run smoke tests (Phase 9)
    │   └── client_jobs/        # Scripts to deploy Cloud Run Scheduler (Phase 9B)
    │
    ├── 1_1_SA_GC_link.py       # Phase 1: verify GCP auth
    ├── 1_2_enable_apis.py      # Phase 1: enable required GCP APIs
    ├── 1_3_assign_iam.py       # Phase 1: grant minimal IAM permissions
    ├── 1_4_bootstrap_resources.py # Phase 1: create datasets and buckets
    ├── 2_1_firestore_to_bq.py  # Phase 2: Firestore collections export
    ├── 2_2_firebase_auth_users_to_bq.py # Phase 2: Firebase Auth users export
    ├── 2_3_build_consolidated.py # Phase 2: consolidate raw payloads
    └── 6_1_run_dbt.py          # Phase 6A: run dbt models
```

---

## 4. Key Architectural Decisions

* **HuggingFace Local Embeddings**: The sync job uses `MiniLM-L6-v2` locally inside the docker container to convert document paragraphs into 384-dimension vectors. This eliminates external embedding API latency and keeps operations completely free of query volume costs.
* **Auto-Fallback LLM (OpenAI → Gemini)**: `llm_client.py` uses OpenAI (`gpt-4o-mini`) as the primary reasoning model. If it encounters a rate limit (HTTP 429) or service interruption, it falls back to Google's Gemini Flash instantly, ensuring 100% chatbot uptime.
* **Metadata visibility access filter**: All document vectors in Pinecone contain a metadata attribute: `visibility = "internal"` or `"external"`. The external customer chatbot queries Pinecone using `filter={"visibility": "external"}`, preventing internal business policy documents from leaking to the public.
