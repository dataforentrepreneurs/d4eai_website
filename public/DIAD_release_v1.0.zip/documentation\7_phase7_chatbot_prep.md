# DIAD Phase 7 — Chatbot Prep (Data Marts)

This phase prepares customer and order data marts that are optimized for direct chatbot querying, resolving PII compliance and indexing schemas.

---

## 1. Chatbot Prep Data Marts

Direct database lookups by the chatbot API rely on two key materialized tables in BigQuery:

1. **`ecommerce_mart.order_dossier_tbl`**:
   - **Purpose**: A comprehensive, consolidated summary of every order.
   - **Contents**: Order details, purchase items, shipping timelines, fulfillment status, and customer contact parameters.
   - **PII Protection**: Designed to resolve safe customer queries while maintaining security.
2. **`ecommerce_mart.customer_360_tbl`**:
   - **Purpose**: A unified profile of customer segments.
   - **Contents**: Total lifetime spend, return rates, average order values, and interaction history details.

---

## 2. Ingestion Scripts

The phase runs the following scripts under `scripts/phase7/` and `scripts/`:

* **Build Order Dossiers (`scripts/phase7/7_1_build_order_dossier_table.py`)**:
  - Compiles staging orders into the order dossier table in BigQuery.
* **Build Customer Profiles (`scripts/phase7/7_1b_build_customer_360_table.py`)**:
  - Compiles order history into the Customer 360 table in BigQuery.
* **Export Json (`scripts/phase7/7_2_export_order_dossier_json.py`)**:
  - Generates JSON summary exports of order dossiers for caching/document indexing.
* **Orchestrator (`scripts/7_run_all.py`)**:
  - Automatically executes all Phase 7 prep steps sequentially.

---

## 3. Run Commands

To rebuild the data marts:
```powershell
# Run the orchestrator to build all tables
python scripts/7_run_all.py

# Or build individual tables manually
python scripts/phase7/7_1_build_order_dossier_table.py --config config/client_rawdata.json
python scripts/phase7/7_1b_build_customer_360_table.py --config config/client_rawdata.json
```
Verify that the output tables exist in BigQuery and are populated.
