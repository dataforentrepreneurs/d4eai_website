# End-to-End Client Journey & Funnel Architecture Guide

This document maps out the complete step-by-step funnel and onboarding journey for a new client—starting from clicking a **LinkedIn Advertisement** to launching their AI chatbots in production.

---

## 🗺️ High-Level Journey Overview

```
[ LinkedIn Ad ] 
       │ (Clicks CTA Link)
       ▼
[ Landing Page: https://diad.d4e.ai/ ]
       │ (Copies 1-line setup command)
       ▼
[ PowerShell Execution: setup.ps1 ]
       │ (Installs Python, GCP CLI, launches local daemon)
       ▼
[ Browser Onboarding Dashboard: http://localhost:8000 ]
       ├── Tab 1: Business Profile & Service Account JSON key
       ├── Tab 2: Connect Google Drive & Docs
       ├── Tab 3: Vault API keys into GCP Secret Manager
       ├── Tab 4: 1-Click Pipeline Execution (BigQuery + dbt + Cloud Run)
       └── Tab 5: Download Client ZIP & Embed Widgets
       ▼
[ Production Live: Website Floating Chat Bubble + Executive Advisor ]
```

---

## 📱 Phase 1: LinkedIn Advertisement & Landing Page (`diad.d4e.ai`)

### 1.1 The LinkedIn Post / Ad Copy
* **Headline**: *"Turn your store's raw data into a 24/7 AI Sales & Customer Support Chatbot inside your own Google Cloud — deployed in under 30 minutes."*
* **Key Hooks**:
  - 🔒 **100% Data Ownership**: Runs inside *your* GCP account. No middleman servers.
  - 📦 **Instant Order dossiers**: Answers tracking & shipment questions with PII masking.
  - 📊 **Executive BI**: Text-to-SQL over revenue, customers, and inventory.
* **Call to Action (CTA Link)**: `https://diad.d4e.ai/`

### 1.2 The Landing Page Content (`diad.d4e.ai`)
When the client clicks the LinkedIn link, `https://diad.d4e.ai/` displays:

1. **Hero Section**: Demo video showing both chatbots answering live questions.
2. **Prerequisites Checklist**:
   - Windows 10/11 machine.
   - A Google Cloud account (free tier works).
   - OpenAI & Pinecone API keys (links provided to get free trial keys).
3. **One-Click Installation Copy-Box**:
   ```powershell
   iwr "https://download.diad.d4e.ai/DIAD_release_v1.0.zip" -OutFile "$env:TEMP\DIAD.zip"; Expand-Archive "$env:TEMP\DIAD.zip" -DestinationPath "$home\DIAD" -Force; Remove-Item "$env:TEMP\DIAD.zip"; cd "$home\DIAD"; .\setup.ps1
   ```

---

## 💻 Phase 2: One-Click Local Setup (`setup.ps1`)

When the user opens PowerShell on their machine and pastes the 1-line command:

1. Downloads `DIAD_release_v1.0.zip` to `$home\DIAD`.
2. Runs `setup.ps1` automatically:
   - ✅ Verifies / installs Python 3.11.
   - ✅ Verifies / installs Google Cloud SDK (`gcloud` CLI).
   - ✅ Creates virtual environment (`venv_dbt`) & installs onboarding requirements.
   - ✅ Launches local daemon `python scripts/onboarding_dashboard.py`.
   - ✅ Opens browser automatically to `http://localhost:8000`.

---

## 🧙‍♂️ Phase 3: The Interactive Onboarding Dashboard (`http://localhost:8000`)

The client follows a guided 5-step tab wizard with an AI Onboarding Mentor on the right panel:

### Tab 1: Account & Business Profile
- Enter Business Name & Website URL.
- Upload GCP Service Account JSON key (`keys/client-service-account.json`).
- Diagnostic banner verifies Python, `gcloud`, and GCP permissions.

### Tab 2: Connect Knowledge Base & Docs
- Paste Google Drive Folder ID containing FAQ documents, return policies, and SOPs.
- Share the Drive folder with the displayed Service Account Email as **Viewer**.
- Optional: Add Notion Token or Confluence Space key.

### Tab 3: Vault API Keys into GCP Secret Manager
- Enter OpenAI API key & Pinecone API key.
- Keys are uploaded directly to the client's **GCP Secret Manager** via `gcloud` CLI.

### Tab 4: Pipeline Execution
- Click **Run** on sequential steps:
  1. Link Service Account & GCP Project.
  2. Enable GCP APIs (BigQuery, Secret Manager, Cloud Run).
  3. Bootstrap BigQuery datasets (`ecommerce_raw`, `ecommerce_canonical`, `ecommerce_mart`).
  4. Ingest sample transaction records.
  5. Run dbt models to build Customer 360 & Order Dossiers.
  6. Deploy `diad-internal-chat` & `diad-external-chat` to Google Cloud Run.

### Tab 5: Download Client Package & Embed
- Click **`⬇️ Download Client ZIP`** to get `diad_integration_package_<client_name>.zip`.
- Contains `diad-chat-widget.js`, `external_chatbot.html`, `internal_chatbot.html`, and `README_FOR_CLIENT.md`.

---

## 🛍️ Phase 4: Website Integration & Operations

1. **Customer Support Chatbot (Storefront)**:
   - Client developer adds `<script src="/diad-chat-widget.js" defer></script>` to their storefront repo.
   - Displays floating chat bubble in bottom-right corner.
   - Customers query order status (e.g. *"Where is my order ORD-100045?"*) or return policies.

2. **Executive Advisor (Internal Staff)**:
   - Staff open `/internal_chatbot` or Cloud Run URL.
   - Run text-to-SQL questions (*"Total revenue last month"*, *"Top 5 customers by spend"*).

---

## 🔄 Phase 5: Automated Maintenance (Quarterly Sync)

- GCP Cloud Scheduler job `diad-phase8-sync-quarterly` (`0 2 1 */3 *`) runs automatically every quarter.
- Refreshes BigQuery marts and updates Pinecone vector embeddings without any manual intervention.
