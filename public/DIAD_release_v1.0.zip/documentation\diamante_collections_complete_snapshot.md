# Diamante Collections — Complete Pre-Teardown Snapshot

> **Purpose**: This document captures **every detail** of the current "The Diamante Collection" setup inside the DIAD platform. It serves as the single source of truth before you tear down the manual configuration and rebuild it via automated onboarding.

> [!IMPORTANT]
> This snapshot was created on **2026-07-17** by examining the live codebase at `d:\DataForEntrepreneurs\diad`. It covers: project structure, configuration, credentials, GCP resources, data pipeline, dbt models, chatbot APIs, document RAG, deployment scripts, and the onboarding dashboard.

---

## 1. Origin of `diad_onboarding_manifest_and_setup_guide.md`

**Was it created by Antigravity in the previous conversation?** **No.**

- The previous conversation (`fbc93f79`) focused on building the **end-to-end client onboarding journey**: [setup.ps1](file:///d:/DataForEntrepreneurs/diad/setup.ps1), [requirements_onboarding.txt](file:///d:/DataForEntrepreneurs/diad/requirements_onboarding.txt), rewriting [readme.md](file:///d:/DataForEntrepreneurs/diad/readme.md), and adding the `/api/diagnostics` endpoint to [onboarding_dashboard.py](file:///d:/DataForEntrepreneurs/diad/scripts/onboarding_dashboard.py).
- The file [diad_onboarding_manifest_and_setup_guide.md](file:///d:/DataForEntrepreneurs/diad/documentation/diad_onboarding_manifest_and_setup_guide.md) is **untracked by git** (`?? documentation/diad_onboarding_manifest_and_setup_guide.md`) and has no commit history. It was likely created by **ChatGPT** (the document itself references "ChatGPT's recommendations" in Section 5).

---

## 2. Project Identity

| Property | Value |
|----------|-------|
| **Business Name** | The Diamante Collection |
| **Website** | `https://thediamantecollections.netlify.app/` |
| **GCP Project ID** | `diamante-diad` |
| **GCP Region** | `asia-southeast1` |
| **Config Version** | 1.1 |
| **Created By** | Nikhil Sahai |
| **Created Date** | 2025-10-23 |
| **Environment** | production |

---

## 3. Complete File Tree

```
d:\DataForEntrepreneurs\diad\
├── .dockerignore                        (254 B)
├── .env.local                           (621 B — API keys, see §5)
├── .gcloudignore                        (493 B)
├── .gitignore                           (organized with section comments)
├── Dockerfile                           (645 B — Python 3.11-slim, uvicorn)
├── env.ps1                              (152 B — sets GOOGLE_CLOUD_PROJECT + creds)
├── env.sh                               (152 B — bash equivalent)
├── readme.md                            (5108 B — client-facing landing page)
├── requirements.txt                     (191 B — full ML stack)
├── requirements_onboarding.txt          (320 B — lightweight FastAPI only)
├── setup.ps1                            (12490 B — one-click client setup)
│
├── config/
│   └── client_rawdata.json              (4295 B — master config, see §4)
│
├── keys/
│   ├── diad-465116-6eb567327a14.json    (2333 B — original DIAD project key)
│   └── diamante-diad-282b6004af56.json  (2359 B — Diamante test project key)
│
├── chatbot/
│   ├── __init__.py                      (17 B)
│   ├── bq_utils.py                      (3808 B — BigQuery client builder)
│   ├── external_api.py                  (18431 B — customer-facing chatbot)
│   ├── internal_api.py                  (18114 B — employee-facing chatbot)
│   ├── llm_client.py                    (9440 B — OpenAI primary, Gemini fallback)
│   └── rag_docs.py                      (10208 B — Pinecone document retrieval)
│
├── scripts/
│   ├── 1_1_SA_GC_link.py                (3336 B — service account linker)
│   ├── 1_2_enable_apis.py               (2393 B — GCP API enabler)
│   ├── 1_3_assign_iam.py                (3197 B — IAM role assigner)
│   ├── 1_4_bootstrap_resources.py       (3964 B — resource bootstrapper)
│   ├── 2_1_firestore_to_bq.py           (14960 B — Firestore → BigQuery)
│   ├── 2_2_firebase_auth_users_to_bq.py (12725 B — Firebase Auth → BigQuery)
│   ├── 2_3_build_consolidated.py        (13653 B — consolidated tables)
│   ├── 3_1_ingest_ecommerce.py          (854 B — orchestrator for phase3/)
│   ├── 6_1_run_dbt.py                   (4654 B — dbt build runner)
│   ├── 7_run_all.py                     (5555 B — chatbot prep orchestrator)
│   ├── gcp_utils.py                     (8564 B — shared GCP helper functions)
│   ├── onboarding_dashboard.py          (90524 B — FastAPI dashboard, 1945 lines)
│   │
│   ├── phase3/
│   │   ├── generate_seed.py             (9036 B — synthetic data generator)
│   │   ├── create_datasets_and_tables.py (1173 B)
│   │   ├── upload_to_gcs.py             (1315 B)
│   │   ├── load_raw_and_transform.py    (5688 B)
│   │   ├── schema.sql                   (3292 B — table DDL)
│   │   └── seed/                        (10 CSV files, see §7)
│   │
│   ├── phase7/
│   │   ├── 7_1_build_order_dossier_table.py   (8740 B)
│   │   ├── 7_1b_build_customer_360_table.py   (6711 B)
│   │   └── 7_2_export_order_dossier_json.py   (7798 B)
│   │
│   ├── phase8/
│   │   ├── 8_1_create_pinecone_index.py       (1239 B)
│   │   ├── 8_2_sync_docs_to_pinecone.py       (36298 B — multi-source crawl + embed)
│   │   ├── 8_3_query_docs.py                  (13194 B)
│   │   └── 8_4_pinecone_status_check.py       (1248 B)
│   │
│   └── phase9/
│       ├── 9_0_preflight.py             (6878 B — health check)
│       ├── 9_1_run_local.ps1            (1398 B — local chatbot runner)
│       ├── 9_2_deploy_cloud_run.ps1     (9767 B — deploy chatbot services)
│       ├── 9_3_smoke_test.ps1           (1286 B — endpoint smoke tests)
│       ├── README.md                    (2598 B)
│       ├── client_jobs/
│       │   ├── env.ps1                  (694 B — per-client env vars)
│       │   ├── 1_bootstrap_project.ps1  (2837 B — enable APIs, create AR, etc.)
│       │   ├── 2_upsert_secrets.ps1     (1342 B — store secrets in SM)
│       │   ├── 3_build_image.ps1        (1254 B — Cloud Build Docker image)
│       │   ├── 4_deploy_job.ps1         (1616 B — deploy Cloud Run Job)
│       │   ├── 5_schedule_job.ps1       (2612 B — create Cloud Scheduler)
│       │   ├── 9_run_all.ps1            (445 B — run all steps sequentially)
│       │   └── README.md               (921 B)
│       └── jobs/                        (additional job configs)
│
├── dbt/
│   ├── profiles/
│   │   └── profiles.yml                 (324 B — BigQuery target config)
│   └── diad_dbt/
│       ├── dbt_project.yml              (281 B — project: diabq, v1.0.0)
│       ├── seeds/
│       │   ├── firebase_auth_users_consolidated.csv (1771 B)
│       │   └── firestore_orders_consolidated.csv    (7350 B)
│       └── models/
│           ├── _sources.yml             (788 B)
│           ├── staging/   (11 models — stg_dim_customer, stg_dim_product, etc.)
│           ├── canonical/ (11 models — dim_customer, payment, shipment, etc.)
│           └── mart/      (3 models — customer_360, order_dossier, orders_flat_line)
│
├── utils/
│   ├── config_loader.py                 (339 B)
│   ├── embeddings.py                    (1107 B — HuggingFace MiniLM-L6-v2)
│   └── pinecone_docs_retriever.py       (3297 B)
│
├── documentation/                       (16 files, see §12)
└── logs/
```

---

## 4. Master Configuration — `client_rawdata.json`

The full config at [config/client_rawdata.json](file:///d:/DataForEntrepreneurs/diad/config/client_rawdata.json):

### 4a. Client Identity
```json
{
  "project_id": "diamante-diad",
  "business_name": "The Diamante Collection",
  "website_url": "https://thediamantecollections.netlify.app/",
  "bq_location": "asia-southeast1",
  "run_date": "2025-07-02",
  "run_date_offset_days": -1
}
```

### 4b. Document Sources (for RAG crawling)
| Source | IDs |
|--------|-----|
| **Google Drive Folders** | `1vgq_MdnsViZT47--rWaeeH64RZRTFEVK`, `11raE-8LmGJ-BSSaLGVjlk9B8W1LcIxOQ` |
| **Notion Parent Pages** | `2c0094b00d9380338a07ecdd00b590f9` |
| **Confluence Parent Page** | `1015809` |

### 4c. Document Visibility (internal vs. external chatbot)
| Source | External (customer-visible) IDs |
|--------|------|
| Drive | `11raE-8LmGJ-BSSaLGVjlk9B8W1LcIxOQ` |
| Notion | `2c4094b00d9380ffb624c4651071724f` |
| Confluence | *(none)* |
| **Defaults** | drive=internal, notion=internal, confluence=internal |

### 4d. Firestore Source
```json
{
  "project_id": "diamante-collections",
  "database": "(default)",
  "dataset": "firestore_export",
  "consolidated_dataset": "firebase_consolidated",
  "collections": ["orders"],
  "date_field": { "orders": "createdAt" }
}
```

### 4e. Firebase Auth Source
```json
{
  "project_id": "diamante-collections",
  "dataset": "firebase_auth_export",
  "table_base": "firebase_auth_users"
}
```

### 4f. Google Analytics Source
```json
{
  "property_id": "502750679",
  "measurement_id": "G-5Q1ZF0LE33",
  "dataset": "google_analytics_export"
}
```

### 4g. Export / GCS Configuration
```json
{
  "bucket": "diamante-diad-storage",
  "compress": false,
  "shard": { "by_date": true, "format": "%Y%m%d" },
  "raw_base": "raw"
}
```

### 4h. Ingestion / Seed Configuration
```json
{
  "gcs_prefix": "landing/phase3",
  "bucket": "diamante-diad-storage",
  "bucket_region": "asia-southeast1",
  "datasets": {
    "raw": "ecommerce_raw",
    "canonical": "ecommerce_canonical",
    "mart": "ecommerce_mart"
  },
  "seed_record_counts": { "customers": 50, "products": 60, "orders": 200 }
}
```

### 4i. Document RAG (Pinecone)
```json
{
  "provider": "pinecone",
  "index_name": "diad-docs-hf",
  "dimension": 384,
  "metric": "cosine",
  "embedding_provider": "huggingface",
  "huggingface_model": "sentence-transformers/all-MiniLM-L6-v2",
  "chunk_tokens": 300,
  "chunk_overlap": 50,
  "top_k": 5
}
```

### 4j. Order Dossier RAG
```json
{
  "mode": "direct_bq",
  "provider": "pinecone",
  "index_name": "diad-order-dossiers-hf",
  "dimension": 384,
  "metric": "cosine"
}
```

### 4k. LLM Configuration
```json
{
  "primary": { "provider": "openai", "model": "gpt-4.1-mini" },
  "fallback": { "provider": "google", "model": "gemini-flash-latest" }
}
```

### 4l. GCP Infrastructure
```json
{
  "region": "asia-southeast1",
  "service_account_key_path": "keys/diamante-diad-282b6004af56.json",
  "target_service_account": "38640153199-compute@developer.gserviceaccount.com",
  "chatbot_deployer_sa": "38640153199-compute@developer.gserviceaccount.com",
  "chatbot_access_sa": "38640153199-compute@developer.gserviceaccount.com",
  "use_gcloud": true
}
```

### 4m. Confluence Integration
```json
{
  "base_url": "https://thediamantecollections.atlassian.net/wiki",
  "username": "the.diamante.collections@gmail.com"
}
```

---

## 5. API Keys & Credentials (from `.env.local`)

> [!CAUTION]
> These are **live API keys** from [.env.local](file:///d:/DataForEntrepreneurs/diad/.env.local). After teardown you'll need to re-provision them (or rotate them for security).

| Secret Name | Prefix / Format | Usage |
|-------------|-----------------|-------|
| `NOTION_API_KEY` | `ntn_O249...` | Notion integration API key for crawling Notion pages |
| `CONFLUENCE_API_TOKEN` | `ATATT3x...` | Atlassian API token for Confluence crawls |
| `PINECONE_API_KEY` | `pcsk_7Y4...` | Pinecone vector database access |
| `OPENAI_API_KEY` | `sk-proj-iy...` | OpenAI GPT-4.1-mini for chatbot synthesis |
| `GEMINI_API_KEY` | `AIzaSyDr...` | Google Gemini Flash fallback LLM |

These same keys are also vaulted in **GCP Secret Manager** under the `diamante-diad` project (provisioned via Tab 3 of the onboarding dashboard or `2_upsert_secrets.ps1`).

---

## 6. GCP Resources (What Exists in the Cloud)

### 6a. Service Accounts
| Name | Email | Purpose |
|------|-------|---------|
| Default Compute SA | `38640153199-compute@developer.gserviceaccount.com` | Used for Cloud Run, deployer, and Secret Accessor |
| diad-deployer-sa | *(manually created)* | Local orchestration |
| diad-scheduler-sa | *(automated via bootstrap)* | Cloud Scheduler invocations |

### 6b. Service Account Key Files
| File | Project |
|------|---------|
| [diad-465116-6eb567327a14.json](file:///d:/DataForEntrepreneurs/diad/keys/diad-465116-6eb567327a14.json) | Original DIAD project |
| [diamante-diad-282b6004af56.json](file:///d:/DataForEntrepreneurs/diad/keys/diamante-diad-282b6004af56.json) | Diamante project |

### 6c. Enabled APIs
- `run.googleapis.com`
- `cloudbuild.googleapis.com`
- `artifactregistry.googleapis.com`
- `secretmanager.googleapis.com`
- `cloudscheduler.googleapis.com`
- `iam.googleapis.com`
- `iamcredentials.googleapis.com`

### 6d. GCS Bucket
| Bucket | Region | Contents |
|--------|--------|----------|
| `gs://diamante-diad-storage/` | asia-southeast1 | `landing/phase3/` CSVs, `raw/` exports |

### 6e. BigQuery Datasets
| Dataset | Layer | Content |
|---------|-------|---------|
| `ecommerce_raw` | Raw / Staging | Landed CSVs (customers, products, orders), GA4, Firebase |
| `ecommerce_canonical` | Canonical | Standardized tables via dbt (dim_customer, payment, shipment, etc.) |
| `ecommerce_mart` | Mart | Aggregate views (customer_360, order_dossier, orders_flat_line) |
| `firestore_export` | Raw | Firestore orders collection |
| `firebase_consolidated` | Consolidated | Merged Firebase data |
| `firebase_auth_export` | Raw | Firebase Auth user exports |
| `google_analytics_export` | Raw | GA4 BigQuery export |

### 6f. Secret Manager Secrets
- `OPENAI_API_KEY`
- `PINECONE_API_KEY`
- `NOTION_API_KEY`
- `CONFLUENCE_API_TOKEN`
- `GEMINI_API_KEY` *(optional)*

### 6g. Cloud Run Services
| Service | Access | Endpoint |
|---------|--------|----------|
| `diad-internal-chat` | Authenticated (no-allow-unauthenticated) | `/internal/chat` |
| `diad-external-chat` | Public | `/external/chat` |

### 6h. Cloud Run Job
| Job | Entry Point | Schedule |
|-----|-------------|----------|
| `diad-sync-docs-job` | `8_2_sync_docs_to_pinecone.py` | Daily via Cloud Scheduler |

### 6i. Cloud Scheduler
| Scheduler | Cron | Timezone |
|-----------|------|----------|
| `diad-sync-docs-scheduler` / `diad-phase8-sync-daily` | `0 2 * * *` | Asia/Singapore |

### 6j. Artifact Registry
| Repository | Image | Tag |
|------------|-------|-----|
| `diad-jobs` | `diad-phase-jobs` | `v1` |

### 6k. Pinecone Vector Indexes
| Index | Dimensions | Metric | Namespace | Usage |
|-------|-----------|--------|-----------|-------|
| `diad-docs-hf` | 384 | cosine | `diamante-docs` | Embedded Drive/Notion/Confluence documents |
| `diad-order-dossiers-hf` | 384 | cosine | *(snapshot mode)* | Order dossier embeddings |

---

## 7. Seed Data Files (Phase 3)

Generated by [generate_seed.py](file:///d:/DataForEntrepreneurs/diad/scripts/phase3/generate_seed.py) with `random.seed(42)`.

| File | Size | Description |
|------|------|-------------|
| `dim_customer.csv` | 8392 B | 50 synthetic customers (Indian names) |
| `dim_product.csv` | 12041 B | 60 products (5 brands: Aurora, Nimbus, Solace, Vertex, Marina) |
| `sales_order_header.csv` | 26813 B | 200 orders |
| `sales_order_line.csv` | 43747 B | Order line items |
| `payment.csv` | 21564 B | Payment records |
| `refund.csv` | 4697 B | Refund records |
| `shipment.csv` | 8342 B | Shipment headers |
| `shipment_item.csv` | 9255 B | Shipment line items |
| `inventory_snapshot_daily.csv` | 1390 B | Daily inventory snapshots |
| `warehouse.csv` | 382 B | Warehouse locations |

All files are in [scripts/phase3/seed/](file:///d:/DataForEntrepreneurs/diad/scripts/phase3/seed/).

---

## 8. dbt Data Model

### 8a. Profile
- **Profile name**: `diabq`
- **Target**: `dev`
- **Method**: `service-account`
- **Keyfile**: `../../keys/diad-3-c58995dd48b6.json` *(Note: references `diamante-diad3` as fallback project)*
- **Default project**: `diamante-diad3` (via `DIAD_PROJECT_ID` env var)
- **Default dataset**: `ecommerce_canonical`
- **Location**: `asia-southeast1`

### 8b. Model Layers

#### Staging (materialized as views in `ecommerce_raw`)
| Model | Source |
|-------|--------|
| `stg_dim_customer` | Raw customer CSV |
| `stg_dim_product` | Raw product CSV |
| `stg_sales_order_header` | Raw order headers |
| `stg_sales_order_line` | Raw order lines |
| `stg_payment` | Raw payments |
| `stg_refund` | Raw refunds |
| `stg_shipment` | Raw shipments |
| `stg_shipment_item` | Raw shipment items |
| `stg_inventory_snapshot_daily` | Raw inventory |
| `stg_firebase_auth_users` | Firebase Auth exports |
| `stg_firestore_orders` | Firestore order exports |

#### Canonical (materialized as tables in `ecommerce_canonical`)
| Model | Purpose |
|-------|---------|
| `dim_customer` | Customer dimension with cleaned fields |
| `dim_identity_account` | Identity resolution accounts |
| `bridge_identity_customer` | Customer ↔ identity bridge |
| `payment` | Standardized payments |
| `refund` | Standardized refunds |
| `sales_order_header` | Standardized order headers |
| `sales_order_line` | Standardized order lines |
| `shipment` | Standardized shipments |
| `shipment_item` | Standardized shipment items |
| `inventory_snapshot_daily` | Standardized inventory |

#### Mart (materialized as views in `ecommerce_mart`)
| Model | Purpose |
|-------|---------|
| `customer_360` | Aggregated customer profile (LTV, order count, etc.) |
| `order_dossier` | Denormalized order with customer, payment, shipment |
| `orders_flat_line` | Flat order line view for reporting |

### 8c. Seeds (loaded into BigQuery)
| Seed File | Purpose |
|-----------|---------|
| `firebase_auth_users_consolidated.csv` | Firebase Auth test users |
| `firestore_orders_consolidated.csv` | Firestore order test data |

---

## 9. Chatbot Architecture

### 9a. Internal API — [internal_api.py](file:///d:/DataForEntrepreneurs/diad/chatbot/internal_api.py)
- **Endpoint**: `POST /internal/chat`
- **Access**: Authenticated (Google IAM)
- **Flow**: Question → Intent classification → SQL template over mart tables → BigQuery execution → LLM summarization
- **Cloud Run Service**: `diad-internal-chat`
- **Local port**: 8001

### 9b. External API — [external_api.py](file:///d:/DataForEntrepreneurs/diad/chatbot/external_api.py)
- **Endpoint**: `POST /external/chat`
- **Access**: Public
- **Flow**: Question + email/order_number → Scoped BQ query + Pinecone doc retrieval → LLM response
- **Cloud Run Service**: `diad-external-chat`
- **Local port**: 8002

### 9c. Shared Modules
| Module | Purpose |
|--------|---------|
| [bq_utils.py](file:///d:/DataForEntrepreneurs/diad/chatbot/bq_utils.py) | Builds BigQuery client from config |
| [llm_client.py](file:///d:/DataForEntrepreneurs/diad/chatbot/llm_client.py) | OpenAI primary + Gemini fallback |
| [rag_docs.py](file:///d:/DataForEntrepreneurs/diad/chatbot/rag_docs.py) | Pinecone document retrieval with MiniLM-L6-v2 |

### 9d. Docker Container
- **Base**: `python:3.11-slim`
- **Default module**: `chatbot.external_api:app`
- **Port**: `${PORT:-8080}`
- **Verification check**: `google.genai` presence

---

## 10. Document RAG Pipeline

### 10a. Sources Crawled
1. **Google Drive** — 2 folder IDs, crawls PDFs/text files
2. **Notion** — 1 parent page ID, crawls child pages recursively
3. **Confluence** — 1 parent page ID from `thediamantecollections.atlassian.net`

### 10b. Embedding
- **Model**: `sentence-transformers/all-MiniLM-L6-v2` (384 dimensions)
- **Chunk size**: 300 tokens, 50 token overlap
- **Provider**: HuggingFace (local inference)

### 10c. Vector Store
- **Provider**: Pinecone
- **Index**: `diad-docs-hf`
- **Namespace**: `diamante-docs`
- **Retrieval**: top-k = 5, cosine similarity

### 10d. Sync Job
- Runs [8_2_sync_docs_to_pinecone.py](file:///d:/DataForEntrepreneurs/diad/scripts/phase8/8_2_sync_docs_to_pinecone.py) (36 KB, the largest script)
- Deployed as Cloud Run Job: `diad-sync-docs-job`
- Scheduled daily at 02:00 SGT

---

## 11. Onboarding Dashboard

### 11a. Server
- **File**: [onboarding_dashboard.py](file:///d:/DataForEntrepreneurs/diad/scripts/onboarding_dashboard.py) (90 KB, 1945 lines)
- **Framework**: FastAPI
- **URL**: `http://localhost:8000`
- **Features**: 3-tab setup wizard + 8-step pipeline runner + mentor chatbot

### 11b. Dashboard Tabs & Steps

| Element | Action | Backend |
|---------|--------|---------|
| **Tab 1: GCP Setup** | Upload service account key JSON | Saves to `keys/`, updates config |
| **Tab 2: Link Sources** | Guide for Drive/Notion/GA4/Firebase sharing | Manual instructions |
| **Tab 3: Secrets Vault** | Enter API keys | Stores in GCP Secret Manager |
| **Step 1** | Preflight Check | `9_0_preflight.py` |
| **Step 2** | Bootstrap GCP | `1_bootstrap_project.ps1` |
| **Step 3** | Upsert Secrets | Link to Tab 3 |
| **Step 4** | Build Docker Image | `3_build_image.ps1` |
| **Step 5** | Deploy Sync Job | `4_deploy_job.ps1` |
| **Step 6** | Deploy Chatbot Services | `9_2_deploy_cloud_run.ps1` |
| **Step 7** | Schedule Daily Sync | `5_schedule_job.ps1` |
| **Step 8** | Smoke Tests | `9_3_smoke_test.ps1` |

### 11c. Diagnostics API
- **Endpoint**: `GET /api/diagnostics`
- **Checks**: Python version, gcloud CLI, config file, SA key file

---

## 12. Documentation Inventory

All 16 files in [documentation/](file:///d:/DataForEntrepreneurs/diad/documentation/):

| # | File | Purpose |
|---|------|---------|
| 0 | `0_diad_architecture.md` | System architecture, folder structure, design decisions |
| 1 | `1_client_gcp_onboarding.md` | GCP admin setup: billing, GA4, OAuth, IAP |
| 2 | `2_phase0_env_bootstrap.md` | SA creation, IAM, GCS buckets, BQ datasets |
| 3 | `3_phase1_config.md` | `client_rawdata.json` schema guide |
| 4 | `4_phase2_firestore_ingestion.md` | Firebase Auth + Firestore → BigQuery |
| 5 | `5_phase3_csv_ingestion.md` | CSV seed ingestion to BQ raw tables |
| 6 | `6_phase6_dbt_modeling.md` | dbt staging → canonical → mart |
| 7 | `7_phase7_chatbot_prep.md` | Order dossier + Customer 360 materialization |
| 8 | `8_phase8_pinecone_sync.md` | Drive/Notion/Confluence crawl + Pinecone sync |
| 9 | `9_phase9_chatbot_deployment.md` | Cloud Run deploy + scheduler + smoke tests |
| 10 | `10_client_onboarding_guide.md` | Non-technical client checklist |
| 11 | `11_admin_client_onboarding.md` | Developer-led admin manual |
| 12 | `12_self_serve_architecture.md` | Self-serve Next.js blueprint |
| 13 | `13_automated_onboarding_guide.md` | Automated portal operations guide |
| - | `README.md` | Documentation index |
| - | `diad_onboarding_manifest_and_setup_guide.md` | ChatGPT-generated manifest *(untracked)* |

---

## 13. Git State

```
Commits (3 total):
  913c8f0  feat: add onboarding dashboard with FastAPI interface and setup script
  74e9907  feat: add self-serve automated client onboarding portal and interactive guide bot
  55aaf1f  Initial commit: DIAD v2 warehouse and chatbot engine with detailed documentation
```

**Untracked files** (not committed):
- `documentation/diad_onboarding_manifest_and_setup_guide.md`
- Various `tmp_gemini_*.py` files
- `keys/*.json` (gitignored)
- `.env.local` (gitignored)
- `config/client_rawdata.json` (gitignored)

---

## 14. External Services & Accounts

| Service | Account/Project | What Was Set Up |
|---------|-----------------|-----------------|
| **GCP (diamante-diad)** | Diamante project | BQ datasets, GCS bucket, Cloud Run, Secret Manager, Scheduler |
| **GCP (diamante-collections)** | Diamante production Firebase | Firestore DB, Firebase Auth |
| **Google Analytics** | Property `502750679` (G-5Q1ZF0LE33) | BigQuery export configured |
| **Google Drive** | 2 shared folders | FAQ/policy documents for RAG |
| **Notion** | Integration + parent page | Knowledge base pages for RAG |
| **Confluence** | `thediamantecollections.atlassian.net` | Knowledge articles for RAG |
| **Pinecone** | 2 indexes | `diad-docs-hf`, `diad-order-dossiers-hf` |
| **OpenAI** | Project API key | GPT-4.1-mini for chatbot |
| **Netlify** | `thediamantecollections.netlify.app` | Customer-facing website |

---

## 15. Pipeline Execution Order (End-to-End)

This is the complete order to recreate the Diamante setup from scratch:

```
Phase 0: Environment & GCP Bootstrap
  1. Create GCP project + enable billing
  2. Create service account + download key JSON
  3. Run 1_2_enable_apis.py (enable 7 GCP APIs)
  4. Run 1_3_assign_iam.py (assign IAM roles)
  5. Run 1_4_bootstrap_resources.py (create GCS bucket, AR repo)

Phase 1: Configuration
  6. Populate config/client_rawdata.json with all project details
  7. Store API keys in .env.local and/or GCP Secret Manager

Phase 2: Firebase/Firestore Ingestion (optional)
  8.  Run 2_1_firestore_to_bq.py
  9.  Run 2_2_firebase_auth_users_to_bq.py
  10. Run 2_3_build_consolidated.py

Phase 3: CSV Seed Ingestion
  11. Run 3_1_ingest_ecommerce.py
      → generate_seed.py → create_datasets_and_tables.py
      → upload_to_gcs.py → load_raw_and_transform.py

Phase 6: dbt Modeling
  12. Activate venv_dbt
  13. Run 6_1_run_dbt.py --mode full
      → staging views → canonical tables → mart views

Phase 7: Chatbot Prep
  14. Run 7_run_all.py
      → order_dossier table → customer_360 table → JSON exports

Phase 8: Document RAG
  15. Run 8_1_create_pinecone_index.py (create index if needed)
  16. Run 8_2_sync_docs_to_pinecone.py (crawl + embed + upsert)

Phase 9: Deployment
  17. Run 1_bootstrap_project.ps1 (enable APIs, create AR, SA roles)
  18. Run 2_upsert_secrets.ps1 (vault secrets)
  19. Run 3_build_image.ps1 (Cloud Build Docker image)
  20. Run 4_deploy_job.ps1 (deploy sync Cloud Run Job)
  21. Run 9_2_deploy_cloud_run.ps1 (deploy internal + external chatbot)
  22. Run 5_schedule_job.ps1 (create daily scheduler)
  23. Run 9_3_smoke_test.ps1 (verify endpoints)
```

---

## 16. Clean Teardown Checklist (Before Automated Rebuild)

> [!WARNING]
> Execute these against `diamante-diad` project. Verify with `gcloud config get-value project` first.

### Cloud Resources to Delete
- [ ] Cloud Scheduler: `diad-sync-docs-scheduler` / `diad-phase8-sync-daily`
- [ ] Cloud Run Job: `diad-sync-docs-job`
- [ ] Cloud Run Services: `diad-internal-chat`, `diad-external-chat`
- [ ] Secret Manager: `OPENAI_API_KEY`, `PINECONE_API_KEY`, `NOTION_API_KEY`, `CONFLUENCE_API_TOKEN`, `GEMINI_API_KEY`
- [ ] BigQuery Datasets: `ecommerce_raw`, `ecommerce_canonical`, `ecommerce_mart`, `firestore_export`, `firebase_consolidated`, `firebase_auth_export`, `google_analytics_export`
- [ ] GCS Bucket contents: `gs://diamante-diad-storage/**`
- [ ] Artifact Registry images: `diad-jobs/diad-phase-jobs:v1`

### Pinecone to Clear
- [ ] Delete all vectors in namespace `diamante-docs` from `diad-docs-hf`
- [ ] Optionally delete entire `diad-order-dossiers-hf` index

### Local Reset
- [ ] Delete `keys/client-service-account.json` (if exists)
- [ ] Reset `config/client_rawdata.json` → `project_id: "Not Configured"`
- [ ] Delete seed CSVs in `scripts/phase3/seed/`
- [ ] Clear `dbt/diad_dbt/target/`

---

## 17. What Your Automated Setup Should Reproduce

When you build the automated setup, the end state should match:

1. ✅ All 7 GCP APIs enabled
2. ✅ Service accounts created with correct IAM roles
3. ✅ 5 secrets in Secret Manager
4. ✅ GCS bucket with seed data landed
5. ✅ 7 BigQuery datasets with correct schemas
6. ✅ dbt models built (11 staging views + 11 canonical tables + 3 mart views)
7. ✅ Order dossier and Customer 360 tables materialized
8. ✅ Pinecone index with embedded documents from Drive/Notion/Confluence
9. ✅ 2 Cloud Run services (internal + external chatbot) responding to requests
10. ✅ 1 Cloud Run Job for daily document sync
11. ✅ Cloud Scheduler trigger at 02:00 SGT daily
12. ✅ Docker image in Artifact Registry
13. ✅ Onboarding dashboard reflecting "all steps complete" state
